﻿
-- 1.MODULE, ACTION 수정
BEGIN
    DBMS_APPLICATION_INFO.SET_MODULE(MODULE_NAME => 'SQL MONITOR'
                                    ,ACTION_NAME => 'SQL TUNING1'
                                    ); 
END;
/

-- 2.MONITOR 힌트를 부여하여 SQL 실행
SELECT /*+ MONITOR */
       AA.*
  FROM SCOTT.EMP AA
;

-- 3.다른 세션에서 리포트 추출
--   1) REPORT_SQL_MONITOR : SQL로 찾기
SELECT DBMS_SQLTUNE.REPORT_SQL_MONITOR(SQL_ID       => A.SQL_ID
                                      ,REPORT_LEVEL => 'ALL'
                                      ,TYPE         => 'TEXT'
                                      ) 
                      AS TEXT 
  FROM (
        SELECT A.SQL_ID
          FROM (
                SELECT A.SQL_ID
                      ,A.SQL_TEXT
                      ,A.PARSING_SCHEMA_NAME
                      ,A.MODULE
                      ,A.ACTION
                      ,A.LAST_ACTIVE_TIME
                  FROM V$SQLAREA A
                 WHERE A.SQL_TEXT         LIKE '%/*+ MONITOR */%'
                   AND A.SQL_TEXT     NOT LIKE '%V$SQL%'
                   AND A.LAST_ACTIVE_TIME   >= SYSDATE - 10/24/60
                   AND A.PARSING_SCHEMA_NAME = 'TUN'
                   AND A.MODULE              = 'SQL MONITOR'
                   AND A.ACTION              = 'SQL TUNING1'
                 ORDER BY A.LAST_ACTIVE_TIME DESC
               ) A
         WHERE ROWNUM = 1
       ) A
;

--   2) REPORT_SQL_MONITOR : 실행 중인 세션에서 찾기
SELECT DBMS_SQLTUNE.REPORT_SQL_MONITOR(SQL_ID       => A.SQL_ID
                                      ,REPORT_LEVEL => 'ALL'
                                      ,TYPE         => 'TEXT'
                                      ) 
                      AS TEXT 
  FROM (
        SELECT A.SQL_ID
          FROM V$SESSION A
         WHERE A.USERNAME   = 'TUN'
           AND A.SCHEMANAME = 'TUN'
           AND A.STATUS   = 'ACTIVE'
           AND A.MODULE   = 'SQL MONITOR'
           AND A.ACTION   = 'SQL TUNING1'
         ORDER BY A.SQL_EXEC_START DESC
        ) A
 WHERE ROWNUM = 1
;

--   3) REPORT_SQL_MONITOR : SQL_MONITOR에서 찾기
SELECT DBMS_SQLTUNE.REPORT_SQL_MONITOR(SQL_ID       => A.SQL_ID
                                      ,REPORT_LEVEL => 'ALL'
                                      ,TYPE         => 'TEXT'
                                      ) 
                      AS TEXT 
  FROM (
        SELECT A.SQL_ID
          FROM V$SQL_MONITOR A
         WHERE A.USERNAME   = 'TUN'
           AND A.STATUS  LIKE 'DONE' || '%'
           AND A.MODULE     = 'SQL MONITOR'
           AND A.ACTION     = 'SQL TUNING1'
         ORDER BY A.SQL_EXEC_START DESC
        ) A
 WHERE ROWNUM = 1
;
