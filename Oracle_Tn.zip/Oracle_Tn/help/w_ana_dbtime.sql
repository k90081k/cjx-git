﻿
* 화면명 : DB time

* 용도 : DB time, CPU time, Wait time의 분포 및 추이 분석

* 주요 딕셔너리
  DBA_HIST_SNAPSHOT
  DBA_HIST_SYS_TIME_MODEL

* 특징
  - DB time = CPU time + Wait time
  - Wait time = DB time - CPU time
  - Wait 비율 : Wait time/DB time
  - DB time 비율1 : 전체 DB time 중 1번 노드의 DB time 비중

  - Time Model : 조회기간의 DBA_SYS_TIME_MODEL 정보
