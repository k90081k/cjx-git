﻿
* 화면명 : SQL Search

* 용도 : SQL Text나 Schema Name, SQL_ID, Program ID 등으로 원하는 정확한 SQL을 조회

* 주요 딕셔너리
  GV$SQL
  DBA_HIST_SQLTEXT
  DBA_HIST_SQLSTAT

* 특징
  - 특정 프로시저나 함수에서 수행한 SQL을 추출하려면, Program의 버튼을 클릭한 후 오브젝트를 선택하여 조회한다

* 참고
  
  -- Single SQL Purge : SYSDBA 권한으로 수행 가능

BEGIN
    DBMS_SHARED_POOL.PURGE(NAME => '<V$SQLAREA.ADDRESS>, <V$SQLAREA.HASH_VALUE>', FLAG => 'C');
END;
/


