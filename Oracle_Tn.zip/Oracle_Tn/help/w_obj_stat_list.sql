﻿
* 화면명 : Table Statistics

* 용도 : 테이블, 인덱스의 통계정보에 대한 개괄적인 분석

* 주요 딕셔너리
  DBA_TABLES
  DBA_INDEXES
  DBA_TAB_COMMENTS

* 특징
  - [통계오류] 체크박스를 클릭하면, 통계정보가 없거나 0건으로 수집된 테이블/인덱스를 추출할 수 있다
  - [Sample Rate] 체크박스를 클릭하면, 지정된 비율 미만으로 통계가 수집된 테이블/인덱스를 추출할 수 있다
  - [경과일수] 체크박스를 클릭하면, 최종 통계수집일자(LAST_ANALYZED)가 지정된 일수를 초과한 수집된 테이블/인덱스를 추출할 수 있다

* 참고
  <DBMS_STAT.GATHER_TABLE_STATS 옵션>
 > ownname          : [계정명] 
 > tabname          : [테이블명]        
 > partname         : [파티션명], 파티션 통계를 수집할 때만 사용
 > estimate_percent : 샘플크기(%)
                      11g에서는 지정하지 않으면(DBMS_STATS.AUTO_SAMPLE_SIZE), hash 알고리즘 사용하여 빠르게 통계 수집, 샘플크기 100% 
                      테스트 결과 임계치는 약 10%임
 > block_sample     : random block sampling instead of random row sampling
                      디폴트 FALSE => random row sampling
                      권장 => FALSE
 > method_opt       : 컬럼 히스토그램 생성 방법
                      디폴트 FOR ALL COLUMNS SIZE AUTO => 컬럼 히스토그램을 오라클 알고리즘으로 수집, 조건절에 많이 사용되는 컬럼 수집
                      권장 => FOR ALL COLUMNS SIZE 1 => 컬럼 히스토그램을 수집하지 않음, 실행계획 안정화 도모
 > degree           : Degree Of Parallelism
 > granularity      : 통계수집 범위
                      ALL          => 테이블과 관련 (서브)파티션
                      GLOBAL       =>테이블
                      PARTITION    => 파티션
                      SUBPARTITION => 서브파티션
                      GLOBAL AND PARTITION => 테이블과 관련 파티션
 > cascade          : 인덱스 통계 생성 여부
                      TRUE  => 테이블 통계를 수집하면서 관련 인덱스도 통계 수집
                      FALSE => 테이블 통계만 수집하고, 인덱스는 통계수집하지 않음
 > no_invalidate    : 관련 커서를 INVALIDATE 시키지 않을지 여부
                      TRUE  => 무효화하지 않음
                      FALSE => 즉시 무효화
                      DBMS_STATS.AUTO_INVALIDATE => 서서히 무효화

 <통계정보 수집 정책 대한 정리>
 - 실행계획의 생성과 유지를 위해, 통계정보는 반드시 필요하다
 - 통계정보를 너무 자주 수집하면 실행계획이 자주 변경되어 실행계획의 안정성을 저해한다
 - 통계정보를 너무 오랫동안 수집하지 않으면, 테이블이나 인덱스간의 시점 차이로 인한 통계정보의 편차가 생길 수 있다
 - 따라서, 통계정보는 주기적으로 수집하되 옵션을 조정하여 실행계획에 미치는 영향도를 최소화 해야 한다

 <실행계획에 영향을 미치는 DBMS_STAT.GATHER_TABLE_STATS 옵션에 대한 권장>
 - estimate_percent : 테이블별로 일정한 비율의 샘플링을 할 수 있도록 한다. 특정 테이블에 대한 샘플비율을 자주 변경하면 안된다.
 - method_opt       : FOR ALL COLUMNS SIZE 1 옵션을 사용하여, 컬럼 히스토그램을 생성하지 않는다.
                      상수로 제공되는 조건을 사용하는 쿼리에는 다소 불리할 수 있으나, 실행계획의 안정성에는 도움이 된다
 - no_invalidate    : TRUE로 지정하여, 커서를 무효화하지 않음
 - granularity      : 파티션된 테이블인 경우, 파티션 통계를 수집하면 조금 더 정교한 통계정보를 이용할 수 있지만,
                      파티션키 조건이 대부분 바인드변수로 제공되므로 파티션 통계를 수집하는 의미가 미약하다.
                      오히려, 0건으로 수집된 파티션 통계가 문제를 일으키는 경우가 종종 있다.
                      따라서, 안정적인 운영을 위해서는 파티션 통계를 수집하지 않은 것이 타당하다.

<통계수집-안정적인 운영을 위한 통계수집 옵션>
BEGIN
    DBMS_STATS.GATHER_TABLE_STATS(OWNNAME          => 'SCOTT'
                                 ,TABNAME          => 'EMP'
                                 ,METHOD_OPT       => 'FOR ALL COLUMNS SIZE 1'    --> 컬럼 히스토그램을 수집하지 않음
                                 ,GRANULARITY      => 'GLOBAL'                    --> 테이블 통계만 수집
                                 ,CASCADE          => TRUE                        --> 인덱스 통계도 수집
                                 ,NO_INVALIDATE    => TRUE                        --> 커서를 무효화하지 않음
                                 ,ESTIMATE_PERCENT => DBMS_STATS.AUTO_SAMPLE_SIZE --> 샘플링 비율을 오라클이 지정(상황에 따라 변경)
                                 ,DEGREE           => 1                           --> PARALLEL을 사용하지 않음   (상황에 따라 변경)
                                 );
END;
/
  ※ 현재 커서의 실행계획을 바꿀 목적으로 통계를 수집하려면, NO_INVALIDATE => FALSE로 지정하여 통계를 수집한다

-- DML 발생현황 즉시 반영 : DBA_TAB_MODIFICATIONS에 반영
BEGIN
    DBMS_STATS.FLUSH_DATABASE_MONITORING_INFO;
END;
/

-- DML 발생현황 확인
SELECT A.OWNER
      ,A.TABLE_NAME
      ,A.NUM_ROWS
      ,A.LAST_ANALYZED        --> 최종 통계수집일자
      ,B.TIMESTAMP            --> 최종 통계수집이후 최종데이터변경일자
      ,B.INSERTS              --> 최종 통계수집이후 INSERT 건수
      ,B.UPDATES              --> 최종 통계수집이후 UPDATE 건수
      ,B.DELETES              --> 최종 통계수집이후 DELETE 건수
      ,B.TRUNCATED            --> 최종 통계수집이후 TRUNCATE 여부
  FROM DBA_TABLES            A
      ,DBA_TAB_MODIFICATIONS B
 WHERE A.OWNER          = 'SCOTT'
   AND A.TABLE_NAME     = 'EMP'
   AND B.TABLE_OWNER(+) = A.OWNER
   AND B.TABLE_NAME (+) = A.TABLE_NAME
;

---------------------------------------------------------------------------------------------------------------------------------------
<자동통계를 이용한 단순한 통계수집 방법>
---------------------------------------------------------------------------------------------------------------------------------------
-- 1.통계수집 옵션 설정 : 컬럼히스토그램을 수집하지 않음, 파티션통계를 수집하지 않음
--   1Og, 11g
BEGIN
    DBMS_STATS.SET_PARAM('METHOD_OPT' , 'FOR ALL COLUMNS SIZE 1');
    DBMS_STATS.SET_PARAM('GRANULARITY', 'GLOBAL'                ); --> Standard Edition은 GRANULARITY가 의미 없음(파티션   사용 불가)
    DBMS_STATS.SET_PARAM('DEGREE'     , '4'                     ); --> Standard Edition은 DEGREE가      의미 없음(PARALLEL 사용 불가)
END;
/

--   11g 이상
BEGIN
    DBMS_STATS.SET_GLOBAL_PREFS('METHOD_OPT' , 'FOR ALL COLUMNS SIZE 1');
    DBMS_STATS.SET_GLOBAL_PREFS('GRANULARITY', 'GLOBAL'                ); --> Standard Edition은 GRANULARITY가 의미 없음(파티션   사용 불가)
    DBMS_STATS.SET_GLOBAL_PREFS('DEGREE'     , '4'                     ); --> Standard Edition은 DEGREE가      의미 없음(PARALLEL 사용 불가)
END;
/

-- 디폴트 옵션으로 변경할 때
BEGIN
    DBMS_STATS.RESET_GLOBAL_PREF_DEFAULTS;
END;
/

-- 2.자동통계의 디폴트 수집시간 조정 : 디폴트 22시에 매일 수행됨 => 매일 새벽 2시에 통계수집 시작
--   1Og : 통계수집 JOB의 시간 설정 변경
BEGIN
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'GATHER_STATS_JOB', ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYHOUR=2;BYMINUTE=0;BYSECOND=0');
END;
/

--   11g : AUTOTASK 윈도우그룹의 시간 설정 변경
BEGIN
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'MONDAY_WINDOW'   , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=MON;BYHOUR=2;BYMINUTE=0;BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'TUESDAY_WINDOW'  , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=TUE;BYHOUR=2;BYMINUTE=0;BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'WEDNESDAY_WINDOW', ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=WED;BYHOUR=2;BYMINUTE=0;BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'THURSDAY_WINDOW' , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=THU;BYHOUR=2;BYMINUTE=0;BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'FRIDAY_WINDOW'   , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=FRI;BYHOUR=2;BYMINUTE=0;BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'SATURDAY_WINDOW' , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=SAT;BYHOUR=2;BYMINUTE=0;BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'SUNDAY_WINDOW'   , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=SUN;BYHOUR=2;BYMINUTE=0;BYSECOND=0');
END;
/

-- 3.최초의 통계수집 스크립트 : 컬럼 히스토그램이 있거나 파티션 통계가 있는 경우 삭제하고 재수집 
BEGIN
    -- WORKAREA 조정
    EXECUTE IMMEDIATE 'ALTER SESSION SET WORKAREA_SIZE_POLICY    = MANUAL   ';
    EXECUTE IMMEDIATE 'ALTER SESSION SET SORT_AREA_SIZE          = 536870912';
    
    -- 기존 통계 삭제 : 오라클 디폴트 계정이 아니면서, 컬럼히스토그램이 있거나 파티션 통계가 있는 경우 삭제하고 재수집
    FOR X IN (
            SELECT B.OWNER
                  ,B.TABLE_NAME
              FROM (
                   -- 대상계정 : 비오라클계정
                    SELECT A.USERNAME             OWNER
                      FROM DBA_USERS A
                     WHERE A.USERNAME NOT IN ('ANONYMOUS','APEX_030200','APEX_PUBLIC_USER','APPQOSSYS','CSMIG','CTXSYS','DBSNMP','DIP','EXFSYS','FLOWS_FILES','MDDATA','MDSYS','MGMT_VIEW','OLAPSYS','ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS','OWBSYS_AUDIT','SCOTT','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYS','SYSMAN','SYSTEM','WMSYS','XDB','XS$NULL')
                   ) A
                  ,(
                   -- 대상 테이블 : 컬럼히스토그램이 있거나, 파티션통계가 있는 테이블
                    SELECT A.OWNER
                          ,A.TABLE_NAME
                      FROM DBA_TAB_COLUMNS A
                     WHERE A.NUM_BUCKETS > 1            --> 컬럼히스토그램이 있거나
                    UNION
                    SELECT A.TABLE_OWNER
                          ,A.TABLE_NAME
                      FROM DBA_TAB_PARTITIONS A
                     WHERE A.LAST_ANALYZED IS NOT NULL  --> 파티션통계가 있는 테이블
                   ) B
                  ,(
                  -- 비대상 테이블 : 통계가 LOCK된 테이블
                    SELECT DISTINCT
                           A.OWNER
                          ,A.TABLE_NAME
                      FROM DBA_TAB_STATISTICS A
                     WHERE A.STATTYPE_LOCKED IS NOT NULL
                   ) C
             WHERE B.OWNER         = A.OWNER
               AND C.OWNER     (+) = B.OWNER
               AND C.TABLE_NAME(+) = B.TABLE_NAME
               AND C.TABLE_NAME IS NULL
             ORDER BY B.OWNER
                     ,B.TABLE_NAME
             )
    LOOP
        DBMS_STATS.DELETE_TABLE_STATS(X.OWNER, X.TABLE_NAME);
        DBMS_STATS.GATHER_TABLE_STATS(X.OWNER, X.TABLE_NAME);
    END LOOP;

    -- WORKAREA 조정
    EXECUTE IMMEDIATE 'ALTER SESSION SET WORKAREA_SIZE_POLICY    = AUTO      ';
END;
/


