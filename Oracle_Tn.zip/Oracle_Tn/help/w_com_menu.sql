﻿● 프로그램명 : ProTun (프로툰)
● 용도 : 오라클 데이터베이스의 딕셔너리를 조회하여, 데이터베이스의 성능을 진단하고 분석한다
● 버전 : 오라클 10g 이상
● 권한 : SELECT ANY DICTIONARY 이상

--------------------------------------------------------------------------------------------------------------------------------------------------
● 메인메뉴
  - Instances   : 데이터베이스, 인스턴스, 파라미터 등에 대한 개괄적인 정보
  - Analysis    : DB 성능에 대한 SYSTEM 측면의 전반적인 분석 지표
  - Objects     : 테이블, 인덱스 등 DB 오브젝트에 대한 분석 및 통계
  - SQL         : TOP SQL 등 SQL 관점의 분석 지표
  - Monitoring  : 세션 등 현재 시점의 데이터베이스 인스턴스 모니터링
  - Customizing : 사용자가 작성한 SQL을 이용하여 화면을 구성
                  \customizing 폴더에 Text 파일 형태로 SQL을 저장하면 이것을 화면에서 디스플레이

--------------------------------------------------------------------------------------------------------------------------------------------------
● 공통 항목
  - 화면에서 조회(Retrieve, F5) 버튼을 누르면, 최신의 정보로 화면을 갱신한다
  - 화면에서 도움말(Help, F1) 버튼을 누르면, 화면에 대한 설명을 보여준다

  - 화면에 DB의 SQL ID가 있는 로우에서 SQL Text(Alt + Q) 버튼을 누르면, 해당 SQL의 전체 문장을 보여준다
  - 화면에 DB의 SQL ID가 있는 로우에서 SQL Stat(Alt + S) 버튼을 누르면, 해당 SQL의 분석 화면(SQL >> SQL Analysis)으로 이동한다
  - 화면에 DB의 TABLE OWNER와 TABLE_NAME이 있는 로우에서 Table Info(Alt + C) 버튼을 누르면, 해당 테이블의 기본정보 화면(Objects >> Table)으로 이동한다

  - 화면에 추출된 데이터에 커서를 두고, 파일로저장 (File >> SaveAsFile ) 버튼을 누르면 화면의 내용을 파일로 저장할 수 있다.
  - 화면에 추출된 데이터에 커서를 두고, 엑셀로저장 (File >> SaveAsExcel) 버튼을 누르면 화면의 내용을 엑셀파일로 저장할 수 있다.
  - 화면에 추출된 데이터에 커서를 두고, 소스SQL보기(File >> Source SQL ) 버튼을 누르면 화면에서 사용된 프로그램의 소스 SQL을 볼 수 있다

--------------------------------------------------------------------------------------------------------------------------------------------------
● 특징
  - 특별한 표기가 없는 한 Size의 단위는 Mb(Mega-Byte)다. 단위가 다를 때는 Gb, Kb 등으로 표시한다.
  - 특별한 표기가 없는 한 Time의 단위는 초(Second)다. 단위가 다를 때는 별도로 표시한다. (Micro-Second : 1/1000000, Milli-Seconed : 1/100)
  - 메뉴 끝에 * 표시가 있는 경우는 기본적이고 중요한 메뉴를 표시한다
  - Standard Edition은 AWR 데이터 중, DBA_HIST_SYSMETRICS만 사용 가능하다

● 서브메뉴
--------------------------------------------------------------------------------------------------------------------------------------------------
 메뉴구조                               용도 및 키워드                                       주요 딕셔너리
--------------------------------------------------------------------------------------------------------------------------------------------------
 Instances                            
    ├ Database Instance*             Database, Instance 기본정보                           V$DATABASE, V$INSTANCE
    ├ DB Parameter                   DB Parameter                                          V$SYSTEM_PARAMETER 
    ├ AWR                            AWR 설정 조회 및 리포트 출력                          DBA_HIST_SNAPSHOT, DBA_HIST_WR_CONTROL
    ├ Tablespace*                    Tablespace 사용 현황 조회                             DBA_TABLESPACES, DBA_SEGMENTS
    ├ Scheduler                      Scheduler 사용 현황 및 로그 조회                      DBA_SCHEDULER_JOBS, DBA_SCHEDULER_JOB_LOG
    │    ├ Scheduler Script         Scheduler Script 생성(DBMS_SCHEDULER)                                     
    │    └ Scheduler Auto Task      Scheduler Auto Task                                   DBA_AUTOTASK_CLIENT, DBA_AUTOTASK_TASK
    ├ Optimzer Statistics            통계정보 수집 정책 조회                               DBA_TABLES, DBA_TAB_COLUMNS, DBA_TAB_PARTITIONS
    ├ OptStat Operations             통계정보 수집 현황 조회                               DBA_OPTSTAT_OPERATIONS
    ├ Tablespace                     Tablespace 사용 현황 조회                             DBA_TABLESPACES, DBA_SEGMENTS
    ├ User Privilege                 사용자 권한 조회                                      DBA_SYS_PRIVS, DBA_TAB_PRIVS, DBA_ROLES
    ├ Alert Log                      Alert Log 조회(11g 이상)                              V$DIAG_ALERT_EXT
    ├ DB Feature Usage               DB 기능 사용 현황 조회                                DBA_FEATURE_USAGE_STATISTICS 
    ├ DB Summary Report*             DB 현황 및 성능 분석 Report                           DBA_HIST_SYS_TIME_MODEL
    ├ Manual AWR Setting             수동 성능 분석 데이터 생성(Stanard Edition용)         V$SYS_TIME_MODEL, V$SYSSTAT, V$SYSTEM_EVENT
    └ Manual AWR Analysis            수동 성능 분석 데이터 분석(Stanard Edition용)         V$SYS_TIME_MODEL, V$SYSSTAT, V$SYSTEM_EVENT
 -------------------------------------------------------------------------------------------------------------------------------------------------
 System Analysis                       
    ├ DB Time*                       DB Time                                               DBA_HIST_SYS_TIME_MODEL
    ├ Wait Class                     Wait Class                                            DBA_HIST_SYSTEM_EVENT
    ├ Wait Event                     Wait Event                                            DBA_HIST_SYSTEM_EVENT
    ├ System Statistics              System Statistics                                     DBA_HIST_SYSSTAT
    ├ System Metric                  System Metric (히트율 등)                             DBA_HIST_SYSMETRIC_SUMMARY
    ├ Resource Usage*                Resource Usage(CPU, 메모리) 현황                      DBA_HIST_SYSMETRIC_SUMMARY, DBA_HIST_SGA, DBA_HIST_PGASTAT
    ├ Segment Statistics*            Segment(테이블, 인덱스) 사용 현황                     DBA_HIST_SEG_STAT
    ├ Metric Compare*                System Metric간의 비교를 통해 성능 이슈 포착          DBA_HIST_SYSMETRIC_SUMMARY
    ├ Trend Compare                  DB Time과 다른 성능 지표와의 비교                     DBA_HIST_SYS_TIME_MODEL, DBA_HIST_SYSSTAT
    ├ Trend Compare Ex               DB 지표간 비교(확장)                                  DBA_HIST_SYS_TIME_MODEL, DBA_HIST_SYSSTAT
    ├ System Stat Trend              특정기간의 주요 System Statitics 추출                 DBA_HIST_SYS_TIME_MODEL, DBA_HIST_SYSSTAT
    ├ Date Compare                   두 일자 사이의 성능 지표 비교                         DBA_HIST_SYS_TIME_MODEL, DBA_HIST_SYSSTAT
    └ ASH Analysis                   ASH Analysis                                          DBA_HIST_ACTIVE_SESS_HISTORY
 -------------------------------------------------------------------------------------------------------------------------------------------------
 Objects                              
    ├ Object Search*                 오브젝트명으로 Object 찾기                            DBA_OBJECTS
    ├ Object List                    계정별 오브젝트 사용 현황 조회                        DBA_OBJECTS
    ├ Table List*                    테이블 목록 조회                                      DBA_TABLES
    ├ Table Modifications            테이블 데이터 변경 현황 조회                          DBA_TAB_MODIFICATIONS
    ├ Index List                     인덱스 목록 조회, 중복 인덱스 조회                    DBA_INDEXES
    ├ Partition List                 파티션된 테이블 목록 조회                             DBA_TAB_PARTITIONS
    ├ Table Statistics               테이블과 인덱스의 통계정보 수집 정보 조회             DBA_TABLES
    ├ Domain Integrity               도메인 무결성에 위배되는 컬럼 찾기                    DBA_TAB_COLUMNS
    ├ Column Search                  컬럼명으로 관련 테이블 조회                           DBA_TAB_COLUMNS
    ├ Table*                         특정 테이블의 관련 정보 조회                          DBA_TABLES
    ├ Table I/O Trend*               특정 테이블의 I/O 추이 보기                           DBA_HIST_SEG_STAT
    ├ Dependency*                    특정 오브젝트(테이블, PL/SQL 등)의 종속관계 조회      DBA_DEPENDENCIES
    └ Table Tuning List              Table 분석 및 튜닝 목록 관리                            
 -------------------------------------------------------------------------------------------------------------------------------------------------
 SQL                                                                                        
    ├ TOP SQL*                       부하 TOP SQL 조회                                     DBA_HIST_SQLSTAT
    ├ Current SQL                    현재 SQL의 부하 분포 조회                             V$SQL
    ├ SQL Analysis*                  특정 SQL의 수행기록, 실행계획, 바인드 변수 등 분석    DBA_HIST_SQLSTAT, V$SQL
    ├ SQL Search*                    SQL Text나 Module 등으로 특정 SQL 찾기                DBA_HIST_SQLTEXT, V$SQL
    ├ PL/SQL Program                 PL/SQL 프로그램의 SQL 성능 분석                       V$SQL
    ├ Literal SQL                    바인드 변수를 사용하지 않는 Literal SQL 조회          V$SQL
    ├ SQL Compare                    특정 SQL간의 일자별 수행기록 비교                     DBA_HIST_SQLSTAT
    ├ SQL Plan Check                 SQL Plan이 2개 이상인 SQL 분석                        V$SQL_SHARED_CURSOR
    ├ Table Access Pattern           특정 테이블의 엑세스 패턴 분석                        DBA_HIST_SQLPLAN, V$SQL_PLAN
    ├ Full Scan Pattern*             테이블 FULL SCAN의 필터 패턴 분석                     DBA_HIST_SQLPLAN, V$SQL_PLAN
    ├ SQL Tuning Advisor             SQL Tuning Advisor 기능 조회                          DBA_ADVISOR_TASKS
    ├ SQL Monitor                    SQL Monitor 기능 조회                                 V$SQL_MONITOR
    └ SQL Tuning List                SQL 분석 및 튜닝 목록 관리                            
 -------------------------------------------------------------------------------------------------------------------------------------------------
 Monitoring                           
    ├ Session*                       세션 조회                                             V$SESSION
    ├ Blocking Session*              블록킹이 발생한 세션의 블로킹 트리 조회                V$SESSION
    ├ SQL Monitoring                 SQL Monitoring(Plan, Time, Stat, Event)               V$SQL, V$SQL_PLAN, V$SESSSTAT
    ├ SQL WorkArea                   SQL WorkArea(Memory, Temp Tablespace) 사용 현황       V$SQL_WORKAREA_ACTIVE
    ├ Lock                           Lock                                                  V$LOCK, V$LOCKED_OBJECT
    ├ Transaction*                   Transaction                                           V$TRANSACTION
    ├ Resouce Monitoring*            Resouce Monitoring(CPU, 메모리) 현황                  V$SYSMETRIC_HISTORY
    ├ Trend Monitoring*              주요 DB 지표의 추이 모니터링                          V$SYSMETRIC_HISTORY
    ├ Redo Log                       Redo Log 현황                                         V$LOGHIST
    └ Active Session History         Active Session History                                V$ACTIVE_SESSION_HISTORY
 -------------------------------------------------------------------------------------------------------------------------------------------------
 Customizing                                                                                
--------------------------------------------------------------------------------------------------------------------------------------------------


* 필요기능
  - 인덱스 설계 강화
  - AUDIT 정리 필요
  - UNDOSTAT, TEMPSTAT
  - INMEMORY 관련 기능(12c)
  - SQL BASELINE

* 프로그램보완기록
  - 2017.11.03 : 로컬PC에 SQL_ID와 매핑하여, SQL의 분석/튜닝 내용을 저장할 수 있는 기능 부여
                 SQL/SQL Tuning List
                 Objects/Table Tuning List
  - 2017.11.13 : System Analysis/Metric Compare 메뉴 추가 => Metric간의 비교를 통해 성능 이슈 확인
  - 2018.02    : System Stat Trend, Table I/O Trend, Blocking Session, Trend Monitoring 추가
                 

