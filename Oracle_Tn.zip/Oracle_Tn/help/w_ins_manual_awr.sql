﻿* 화면명 : Manual AWR Create

* 용도 : Standard 버전 등 AWR 기능이 없는 오라클 버전에서 시스템 성능을 체크하는 자료 생성

* 주요 딕셔너리
  GV$SYS_TIME_MODEL
  GV$SYSSTAT
  GV$SYSTEM_EVENT
  GV$OSSTAT
  GV$SYSMETRIC
  GV$SGA
  GV$PGASTAT
  GV$SEGSTAT
  GV$SQLAREA

* 사용방법
  1) 특정시점에 Create Snapshot 버튼을 클릭 : 현재 시점의 성능 지표 저장
  2) 적당한 시간(1시간 또는 업무시간)이 경과한 후에 Create Snapshot 버튼을 클릭 : 현재 시점을 성능 지표를 저장한 후에 이전 시점의 데이터와 비교하여 차이를 보여줌
  3) Save Snapshot File1 또는 Save Snapshot File2 버튼을 눌러 엑셀 파일로 성능 지표를 저장
     - Save Snapshot File1 : 성능지표마다 파일을 따로 생성하며, 속도가 빠름
     - Save Snapshot File2 : 하나의 엑셀파일에 성능 지표를 시트로 분리하여 보여주며, 생성 속도가 느림

* 특징
  