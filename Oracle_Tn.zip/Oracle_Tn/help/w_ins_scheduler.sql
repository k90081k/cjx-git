﻿
* 화면명 : Scheduler

* 용도 : 스케줄러에 등록된 JOB에 대한 조회 및 수행기록 분석

* 주요 딕셔너리
  DBA_SCHEDULER_JOBS
  DBA_SCHEDULER_JOB_RUN_DETAILS

* 특징


---------------------------------------------------------
* 참고 : 클라이언트(PC)에서 서버 작업을 구동하는 방법
---------------------------------------------------------
1) 클라이언트 작업의 문제점
   - 일반적으로 클라이언트에서 장시간 소요되는 작업을 수행하면 작업이 끊길 위험이 있다
     (사용자 실수, DB 타임아웃, 접근제어 등등)
   - 또한 작업이 완료되지 않으면 PC 전원을 끌 수도 없다
   - 이런 이유로 중요하나 작업을 수행할 때는 서버에서 수행해야 한다
2) 서버에서 DB 작업을 구동하려면, 서버접속 -> 스크립트 파일 생성 -> 백그라운드 작업 구동 등의 번거로운 절차가 필요하다
3) DB 작업이면서 장기간 시간이 소요되는 작업은 DB의 스케줄러를 이용하여 서버에서 수행할 수 있다.
4) 필요권한 : 해당 DB 계정에 CREATE JOB 권한이 있어야 한다
5) 방법 : 작업 내용은 오렌지나 토드, SQL*PLUS 등으로 수행할 수 있는 간단하고, 시간이 오래걸리는 작업이라고 가정한다

   - 작업 스크립트 생성
     INSERT INTO SCOTT1.EMP SELECT * FROM SCOTT2.EMP; COMMIT;

   - 스케줄러 등록
BEGIN
    DBMS_SCHEDULER.CREATE_JOB(JOB_NAME    => 'JB_TEMP_01'            --> JOB이름 : 임의로 지정
                             ,JOB_TYPE    => 'PLSQL_BLOCK'           --> JOB유형 : ANONYMOUS PL/SQL BLOCK
                             ,JOB_ACTION  => 'BEGIN INSERT INTO SCOTT1.EMP SELECT * FROM SCOTT2.EMP; COMMIT; END;'                      
                                                                     --> 수행할 작업내용 : ANONYMOUS PL/SQL BLOCK 방식으로 기술, 작업내용을 BEGIN END;안에 기술, 세미콜론 필수
                             ,START_DATE  => SYSDATE                 --> 시작시간 : ENABLE 즉시 수행
                             ,ENABLED     => TRUE                    --> ENABLE여부 : ENABLE은 즉시 수행
                             ,AUTO_DROP   => TRUE                    --> 수행종료 후 JOB SCHEDULER에서 자동 삭제 여부
                             ,COMMENTS    => 'TEMP JOB'              --> 작업코멘트 : 옵션
                             );
END;
/



