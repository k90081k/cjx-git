﻿
* 화면명 : Session

* 용도 : 현재 데이터베이스 인스턴의 세션정보 분석

* 주요 딕셔너리
  GV$SESSION
  GV$PROCESS
  DBA_OBJECTS

* 특징

* 참고

  -- Kill Session
  ALTER SYSTEM KILL SESSION 'sid,serial#';