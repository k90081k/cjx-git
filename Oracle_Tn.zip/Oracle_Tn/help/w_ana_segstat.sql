﻿
* 화면명 : Segment Statistics

* 용도 : 세그먼트별 사용량 및 사용 추이 분석

* 주요 딕셔너리
  DBA_HIST_SEG_STAT
  DBA_HIST_SEG_STAT_OBJ

* 특징
  - 지표를 더블클릭하면, 특정 오브젝트의 특정 지표에 대한 발생추이를 그래프로 볼 수 있다
  - [Table] 버튼을 클릭하면, 특정 오브젝트의 부모 테이블에 대한 정보를 볼 수 있다

* 참고
