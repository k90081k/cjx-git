﻿/*
-- 필요 권한
GRANT ANALYZE ANY           TO [패키지소유계정];
GRANT SELECT ANY DICTIONARY TO [패키지소유계정];
GRANT SELECT ANY TABLE      TO [패키지소유계정];
*/

CREATE OR REPLACE PACKAGE PKG_STAT
/* -------------------------------------------------------------------------------------
* 용도 : 통계정보 수집
*        1.테이블 단위 통계수집
*        2.기타 : 통계수집 로그 기능, 통계정보 백업 기능, 통계 스케줄링 기능 보완 필요
---------------------------------------------------------------------------------------- */
IS
-- 테이블 통계 수집
PROCEDURE TABLE_STAT (PV_OWNER         IN VARCHAR2
                     ,PV_TABLE_NAME    IN VARCHAR2
                     ,PV_NO_INVALIDATE IN NUMBER   DEFAULT 1);

-- 테이블의 데이터 존재 여부 체크
FUNCTION  DATA_EXIST (PV_OWNER         IN VARCHAR2
                     ,PV_TABLE_NAME    IN VARCHAR2)
RETURN NUMBER;

END;
/

-- 패키지 바디
CREATE OR REPLACE PACKAGE BODY PKG_STAT
IS
--******************************************************************************
-- 테이블의 데이터 존재 여부 체크
FUNCTION DATA_EXIST(PV_OWNER         IN VARCHAR2
                   ,PV_TABLE_NAME    IN VARCHAR2)
RETURN NUMBER
IS
V_RUN_STR   VARCHAR2(200);
V_ROW_COUNT NUMBER;
BEGIN
    V_RUN_STR := 'SELECT /*+ INDEX(A) */ COUNT(*) FROM ' || PV_OWNER || '.' || PV_TABLE_NAME || ' A WHERE ROWNUM <= 1';

    EXECUTE IMMEDIATE V_RUN_STR INTO V_ROW_COUNT;

    RETURN V_ROW_COUNT;
EXCEPTION WHEN OTHERS
   THEN RETURN NULL;
END;

--******************************************************************************
-- 테이블 통계 수집
PROCEDURE TABLE_STAT   (PV_OWNER         IN VARCHAR2
                       ,PV_TABLE_NAME    IN VARCHAR2
                       ,PV_NO_INVALIDATE IN NUMBER   DEFAULT 1)
IS
/*
----------------------------------------------------------------------------
-- 용도 : 테이블 단위로 통계를 수집하는 프로시저
-- 특징 : 테이블의 ROW를 체크하여 0건이면 통계를 수집하지 않음
----------------------------------------------------------------------------
*/
-- 변수
V_OWNER            VARCHAR2(30) ;
V_TABLE_NAME       VARCHAR2(30) ;

-- 상수 : 옵션 고정
V_METHOD_OPT       VARCHAR2(100) := 'FOR ALL COLUMNS SIZE 1';  -- 컬럼 히스토그램을 생성하지 않음
V_GRANULARITY      VARCHAR2(100) := 'GLOBAL';                  -- 테이블 통계정보만 생성, (서브)파티션 통계정보는 생성하지 않음
V_CASCADE          BOOLEAN       := TRUE;                      -- 인덱스 통계정보도 함께 생성
V_NO_INVALIDATE    BOOLEAN       := TRUE;                      -- 현재 커서를 유지함(커서를 무효화하지 않음)

-- 변수 : 테이블 사이즈에 따라 변경
V_BASE_SIZE        NUMBER        := 1000;                      -- 100%를 수집하는 기준크기 => 1Gb
V_TABLE_SIZE       NUMBER       ;
V_SAMPLE_PERCENT   NUMBER       ;
V_DOP              NUMBER       ;

-- 기타
V_ROW_COUNT        NUMBER       ;
V_RUN_STR          VARCHAR2(200);
BEGIN
    -----------------------------------------------------------------------------
    -- ARGUMENT 할당
    -----------------------------------------------------------------------------
    V_OWNER      := PV_OWNER     ;
    V_TABLE_NAME := PV_TABLE_NAME;

    IF V_OWNER IS NULL OR V_TABLE_NAME IS NULL THEN
        RETURN;
    END IF;

    IF PV_NO_INVALIDATE = 0 THEN
        V_NO_INVALIDATE := FALSE;
    ELSE
        V_NO_INVALIDATE := TRUE;
    END IF;
    
    -----------------------------------------------------------------------------
    -- ROW가 존재하는지 체크하여, 건수가 없으면 통계수집을 수행하지 않음
    -----------------------------------------------------------------------------
    V_ROW_COUNT := DATA_EXIST(V_OWNER, V_TABLE_NAME);
    
    IF V_ROW_COUNT = 0 THEN
        -- 기존 통계정보가 0건이면, 통계를 삭제한 후 종료
        SELECT MAX(A.NUM_ROWS)
          INTO V_ROW_COUNT
          FROM DBA_TABLES A
         WHERE A.OWNER      = V_OWNER
           AND A.TABLE_NAME = V_TABLE_NAME
           AND A.NUM_ROWS   = 0
        ;

        IF V_ROW_COUNT = 0 THEN
            DBMS_STATS.DELETE_TABLE_STATS(OWNNAME       => V_OWNER
                                         ,TABNAME       => V_TABLE_NAME
                                         ,NO_INVALIDATE => V_NO_INVALIDATE
                                         );
        END IF;

        RETURN;
    END IF;
    
    -----------------------------------------------------------------------------
    -- 세그먼트 사이즈를 체크하여 샘플비율, DOP를 구함
    -----------------------------------------------------------------------------
    SELECT CASE WHEN A.TABLE_SIZE <= A.BASE_SIZE
             THEN 100                         --> 10g
                  --DBMS_STATS.AUTO_SAMPLE_SIZE --> 11g
             ELSE GREATEST(ROUND((A.BASE_SIZE*10)/A.TABLE_SIZE, 1), 0.1)
           END                 SAMPLE_PERCENT  --> Sample Rate
          ,CASE
             WHEN A.TABLE_SIZE <= A.BASE_SIZE*POWER(10,-1) THEN 1
             WHEN A.TABLE_SIZE <= A.BASE_SIZE*POWER(10, 0) THEN 2
             WHEN A.TABLE_SIZE <= A.BASE_SIZE*POWER(10, 1) THEN 4
             WHEN A.TABLE_SIZE >  A.BASE_SIZE*POWER(10, 1) THEN 8
           END                 DOP             --> Degree Of Parallelism
      INTO V_SAMPLE_PERCENT
          ,V_DOP
      FROM (
           SELECT ROUND(SUM(A.BYTES)/1024/1024)
                                         TABLE_SIZE
                 ,V_BASE_SIZE            BASE_SIZE
             FROM DBA_SEGMENTS A
            WHERE A.OWNER           = V_OWNER
              AND A.SEGMENT_NAME    = V_TABLE_NAME
              AND A.SEGMENT_TYPE LIKE 'TABLE%'
           ) A
    ;
    
    -----------------------------------------------------------------------------
    -- 통계수집
    -----------------------------------------------------------------------------
    DBMS_STATS.GATHER_TABLE_STATS(OWNNAME          => V_OWNER
                                 ,TABNAME          => V_TABLE_NAME
                                 ,ESTIMATE_PERCENT => V_SAMPLE_PERCENT
                                 ,METHOD_OPT       => V_METHOD_OPT
                                 ,GRANULARITY      => V_GRANULARITY
                                 ,DEGREE           => V_DOP
                                 ,CASCADE          => V_CASCADE
                                 ,NO_INVALIDATE    => V_NO_INVALIDATE
                                 );
    -----------------------------------------------------------------------------
    
    -- EXCEPTION 발생시 처리
    EXCEPTION WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE(SUBSTRB(SQLERRM, 1, 200));
END;

--******************************************************************************
END;
/

-- 일반적인 통계생성
BEGIN
    PKG_STAT.TABLE_STAT('SCOTT', 'EMP');
END;
/

-- 특수한 통계생성 옵션 : 현재 커서를 즉시 무효화함, Hard Parsing 유도
BEGIN
    PKG_STAT.TABLE_STAT('SCOTT', 'EMP', 0);
END;
/

-- 전체 테이블 통계생성
BEGIN
    FOR X IN (
              SELECT A.OWNER
                    ,A.TABLE_NAME
                FROM DBA_TABLES A
               WHERE A.OWNER IN ('SCOTT', 'TUN')
               ORDER BY A.OWNER
                       ,A.TABLE_NAME
             )
    LOOP
        PKG_STAT.TABLE_STAT(X.OWNER, X.TABLE_NAME);
    END LOOP;
END;
/
