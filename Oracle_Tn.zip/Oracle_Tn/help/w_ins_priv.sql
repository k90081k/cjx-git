﻿
* 화면명 : User Privilege

* 용도 : User의 System Privilege와 Object Privilege에 대한 조회

* 주요 딕셔너리
  DBA_ROLE_PRIVS
  DBA_SYS_PRIVS
  DBA_TAB_PRIVS
  DBA_USERS
  DBA_OBJECTS

* 특징
  - [User System Privilege] 탭 : 특정 User가 가진 System Privilege 조회
  - [User Object Privilege] 탭 : 특정 User가 가진 Object Privilege 조회
  - [System Privilege & User] 탭 : 특정 System Privilege를 가진 User 조회
  - [Object Privilege & User] 탭 : 특정 Object Privilege를 가진 User 조회

