﻿* 화면명 : AWR (Active Workload Repository)

* 용도 : AWR의 현재 설정 상황, SNAPSHOT 조회, AWR 리포트 추출

* 주요 딕셔너리
  DBA_HIST_WR_CONTROL
  DBA_DATA_FILES
  DBA_SEGMENTS

* 특징
   - AWR 설정과 SYSAUX 사용량 조회 체크박스를 클릭하면, 현재 AWR 설정 상황을 조회할 수 있다
   - [Report 생성] 버튼을 클릭하면, DBMS_WORKLOAD_REPOSITORY 패키지를 이용하여, 조회한 스냅구간에 해당하는 AWR 리포트를 추출할 수 있다
     1) 인스턴스 개별 : DBMS_WORKLOAD_REPOSITORY.AWR_REPORT_HTML
     2) 인스턴스 전체 : DBMS_WORKLOAD_REPOSITORY.AWR_GLOBAL_REPORT_HTML

* 참고
  - 스냅샷 생성 스크립트
BEGIN
     DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT;
END;
/

  - 보관주기 변경
BEGIN
    DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS(RETENTION => 70*(24*60));  --> 보관주기 70일
END;
/

  - 수집주기 변경
BEGIN
    DBMS_WORKLOAD_REPOSITORY.MODIFY_SNAPSHOT_SETTINGS(INTERVAL  => 60);  --> 수집주기 60분
END;
/


---------------------------------------------------------------------------------------------------------------
 - Summary of DBMS_WORKLOAD_REPOSITORY Subprograms
---------------------------------------------------------------------------------------------------------------
ADD_COLORED_SQL Procedure
 Adds a colored SQL ID
 
ASH_GLOBAL_REPORT_HTML Function
 Displays a global or Oracle Real Application Clusters (Oracle RAC) ASH Spot report in HTML format.
 
ASH_GLOBAL_REPORT_TEXT Function
 Displays a global or Oracle Real Application Clusters (Oracle RAC) ASH Spot report in Text format.
 
ASH_REPORT_HTML Function
 Displays the ASH report in HTML
 
ASH_REPORT_TEXT Function
 Displays the ASH report in text
 
AWR_DIFF_REPORT_HTML Function
 Displays the AWR Diff-Diff report in HTML
 
AWR_DIFF_REPORT_TEXT Function
 Displays the AWR Diff-Diff report in text
 
AWR_GLOBAL_DIFF_REPORT_HTML Functions
 Displays the Global AWR Compare Periods Report in HTML
 
AWR_GLOBAL_DIFF_REPORT_TEXT Functions
 Displays the Global AWR Compare Periods Report in text
 
AWR_GLOBAL_REPORT_HTML Functions
 Displays the Global AWR report in HTML
 
AWR_GLOBAL_REPORT_TEXT Functions
 Displays the Global AWR report in text
 
AWR_REPORT_HTML Function
 Displays the AWR report in HTML
 
AWR_REPORT_TEXT Function
 Displays the AWR report in text
 
AWR_SQL_REPORT_HTML Function
 Displays the AWR SQL Report in HTML format
 
AWR_SQL_REPORT_TEXT Function
 Displays the AWR SQL Report in text format
 
CREATE_BASELINE Functions & Procedures
 Creates a single baseline
 
CREATE_BASELINE_TEMPLATE Procedures
 Creates a baseline template
 
CREATE_SNAPSHOT Function and Procedure
 Creates a manual snapshot immediately
 
DROP_BASELINE Procedure
 Drops a range of snapshots
 
DROP_BASELINE_TEMPLATE Procedure
 Removes a baseline template that is no longer needed
 
DROP_SNAPSHOT_RANGE Procedure
 Activates service
 
MODIFY_SNAPSHOT_SETTINGS Procedures
 Modifies the snapshot settings
 
MODIFY_BASELINE_WINDOW_SIZE Procedure
 Modifies the window size for the Default Moving Window Baseline
 
RENAME_BASELINE Procedure
 Renames a baseline
 
SELECT_BASELINE_METRICS Function
 Shows the values of the metrics corresponding to a baseline
---------------------------------------------------------------------------------------------------------------
