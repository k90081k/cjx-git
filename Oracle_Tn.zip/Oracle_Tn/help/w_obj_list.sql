﻿
* 화면명 : Object List

* 용도 : 특정 USER별로 소유하는 DB 오브젝트 목록 조회

* 주요 딕셔너리
  DBA_OBJECTS
  DBA_USERS

* 특징
  - 특정 USER의 특정 오브젝트 유형을 더블클릭하면, 해당하는 오브젝트를 볼 수 있다

* 참고
