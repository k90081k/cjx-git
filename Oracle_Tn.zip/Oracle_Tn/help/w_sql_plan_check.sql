﻿
* 화면명 : SQL Plan Check

* 용도 : 하나의 SQL에 실행계획이 2개인 경우를 추출하고 분석

* 주요 딕셔너리
  GV$SQL
  DBA_HIST_SQLSTAT
  GV$SQL_SHARED_CURSOR
  GV$SQL_OPTIMIZER_ENV

* 특징
  - SQL Shared Cursor나 SQL Optimizer ENV를 조회하여 실행계획이 다른 원인을 찾도록 한다

* 참고

  <실행계획이 올바르지 못할 때, 실행계획을 변경하는 방법>
 -------------------------------------------------------------------------------
  방법         영향범위   비고
 -------------------------------------------------------------------------------
  SQL 변경      SQL       SQL 변경을 통한 엑세스 패턴 변경 유도
  HINT 사용     SQL       힌트 사용을 통한 엑세스 패턴 변경 유도
  커서삭제      SQL       기존 커서 삭제를 통한 하드 파싱 유도(11g 이상에서 가능)
  SQL Profile   SQL       SQL Profile을 통한 OutLine 지정으로 엑세스 패턴 변경 유도
  SQL Baseline  SQL       SQL Baseline 변경을 통한 엑세스 패턴 변경 유도(11g 이상에서 가능)
  인덱스 생성   테이블    인덱스 생성을 통한 신규 엑세스 패턴 유도
  통계재생성    테이블    NO_INVALIDATE = FALSE 옵션 지정을 통한 하드 파싱 유도
  통계복구      테이블    NO_INVALIDATE = FALSE 옵션 지정을 통한 하드 파싱 유도
 -------------------------------------------------------------------------------

 <V$SQL_SHARED_CURSOR Column Description>
----------------------------------------------------------------------------------------------------------------
Column                          Description
----------------------------------------------------------------------------------------------------------------
UNBOUND_CURSOR                : The existing child cursor was not fully built (in other words, it was not optimized)
SQL_TYPE_MISMATCH             : The SQL type does not match the existing child cursor
OPTIMIZER_MISMATCH            : The optimizer environment does not match the existing child cursor
OUTLINE_MISMATCH              : The outlines do not match the existing child cursor
STATS_ROW_MISMATCH            : The existing statistics do not match the existing child cursor
LITERAL_MISMATCH              : Non-data literal values do not match the existing child cursor
FORCE_HARD_PARSE              : For internal use
EXPLAIN_PLAN_CURSOR           : The child cursor is an explain plan cursor and should not be shared
BUFFERED_DML_MISMATCH         : Buffered DML does not match the existing child cursor
PDML_ENV_MISMATCH             : PDML environment does not match the existing child cursor
INST_DRTLD_MISMATCH           : Insert direct load does not match the existing child cursor
SLAVE_QC_MISMATCH             : The existing child cursor is a slave cursor and the new one was issued by the coordinator
                                (or, the existing child cursor was issued by the coordinator and the new one is a slave cursor)
TYPECHECK_MISMATCH            : The existing child cursor is not fully optimized
AUTH_CHECK_MISMATCH           : Authorization/translation check failed for the existing child cursor
BIND_MISMATCH                 : The bind metadata does not match the existing child cursor
DESCRIBE_MISMATCH             : The typecheck heap is not present during the describe for the child cursor
LANGUAGE_MISMATCH             : The language handle does not match the existing child cursor
TRANSLATION_MISMATCH          : The base objects of the existing child cursor do not match
BIND_EQUIV_FAILURE            : The bind value's selectivity does not match that used to optimize the existing child cursor
INSUFF_PRIVS                  : Insufficient privileges on objects referenced by the existing child cursor
INSUFF_PRIVS_REM              : Insufficient privileges on remote objects referenced by the existing child cursor
REMOTE_TRANS_MISMATCH         : The remote base objects of the existing child cursor do not match
LOGMINER_SESSION_MISMATCH     : LogMiner Session parameters mismatch
INCOMP_LTRL_MISMATCH          : Cursor might have some binds (literals) which may be unsafe/non-data. Value mismatch.
OVERLAP_TIME_MISMATCH         : Mismatch caused by setting session parameter ERROR_ON_OVERLAP_TIME
EDITION_MISMATCH              : Cursor edition mismatch
MV_QUERY_GEN_MISMATCH         : Internal, used to force a hard-parse when analyzing materialized view queries
USER_BIND_PEEK_MISMATCH       : Cursor is not shared because value of one or more user binds is different and this has a potential to change the execution plan
TYPCHK_DEP_MISMATCH           : Cursor has typecheck dependencies
NO_TRIGGER_MISMATCH           : Cursor and child have no trigger mismatch
FLASHBACK_CURSOR              : Cursor non-shareability due to flashback
ANYDATA_TRANSFORMATION        : Is criteria for opaque type transformation and does not match
INCOMPLETE_CURSOR             : Cursor is incomplete: typecheck heap came from call memory
PDDL_ENV_MISMATCH             : Environment setting mismatch for parallel DDL cursor
TOP_LEVEL_RPI_CURSOR          : Is top level RPI cursor
DIFFERENT_LONG_LENGTH         : Value of LONG does not match
LOGICAL_STANDBY_APPLY         : Logical standby apply context does not match
DIFF_CALL_DURN                : If Slave SQL cursor/single call
BIND_UACS_DIFF                : One cursor has bind UACs and one does not
PLSQL_CMP_SWITCHS_DIFF        : PL/SQL anonymous block compiled with different PL/SQL compiler switches
CURSOR_PARTS_MISMATCH         : Cursor was compiled with subexecution (cursor parts were executed)
STB_OBJECT_MISMATCH           : STB is an internal name for a SQL Management Object Mismatch. 
                                A SQL Management Object Mismatch means that either a SQL plan baseline, or a SQL profile, or a SQL patch has been created 
                                for your SQL statement between the executions. 
                                Because a cursor is a read-only entity, a hard parse is forced to be able to create a new cursor 
                                that contains information about the new SQL management object related to this SQL statement.
CROSSEDITION_TRIGGER_MISMATCH : The set of crossedition triggers to execute might differ
PQ_SLAVE_MISMATCH             : Top-level slave decides not to share cursor
TOP_LEVEL_DDL_MISMATCH        : Is top-level DDL cursor
MULTI_PX_MISMATCH             : Cursor has multiple parallelizers and is slave-compiled
BIND_PEEKED_PQ_MISMATCH       : Cursor based around bind peeked values
MV_REWRITE_MISMATCH           : Cursor needs recompilation because an SCN was used during compile time due to being rewritten by materialized view
ROLL_INVALID_MISMATCH         : Marked for rolling invalidation and invalidation window exceeded
OPTIMIZER_MODE_MISMATCH       : Parameter OPTIMIZER_MODE mismatch (for example, all_rows versus first_rows_1)
PX_MISMATCH                   : Mismatch in one parameter affecting the parallelization of a SQL statement. 
                                For example, one cursor was compiled with parallel DML enabled while the other was not.
MV_STALEOBJ_MISMATCH          : Cursor cannot be shared because there is a mismatch in the list of materialized views which were stale at the time the cursor was built
FLASHBACK_TABLE_MISMATCH      : Cursor cannot be shared because there is a mismatch with triggers being enabled and/or referential integrity constraints being deferred
LITREP_COMP_MISMATCH          : Mismatch in use of literal replacement
PLSQL_DEBUG                   : Value of the PLSQL_DEBUG parameter for the current session does not match the value used to build the cursor
LOAD_OPTIMIZER_STATS          : A hard parse is forced in order to initialize extended cursor sharing
ACL_MISMATCH                  : Cached ACL evaluation result stored in the child cursor is not valid for the current session or user
FLASHBACK_ARCHIVE_MISMATCH    : Value of the FLASHBACK_DATA_ARCHIVE_INTERNAL_CURSOR parameter for the current session does not match the value used to build the cursor
LOCK_USER_SCHEMA_FAILED       : User or schema used to build the cursor no longer exists
REMOTE_MAPPING_MISMATCH       : Reloaded cursor was previously remote-mapped and is currently not remote-mapped. Therefore, the cursor needs to be reparsed.
LOAD_RUNTIME_HEAP_FAILED      : Loading of runtime heap for the new cursor (or reload of aged out cursor) failed
HASH_MATCH_FAILED             : No existing child cursors have the unsafe literal bind hash values required by the current cursor
PURGED_CURSOR                 : Child cursor is marked for purging
BIND_LENGTH_UPGRADEABLE       : Bind length(s) required for the current cursor are longer than the bind length(s) used to build the child cursor
USE_FEEDBACK_STATS            : A hard parse is forced so that the optimizer can reoptimize the query with improved cardinality estimates
----------------------------------------------------------------------------------------------------------------

BIND_EQUIV_FAILURE       The bind value s selectivity does not match that used to optimize the existing child cursor
BIND_LENGTH_UPGRADEABLE  Bind length(s) required for the current cursor are longer than the bind length(s) used to build the child cursor
HASH_MATCH_FAILED        No existing child cursors have the unsafe literal bind hash values required by the current cursor
LOAD_OPTIMIZER_STATS     A hard parse is forced to initialize extended cursor sharing
PURGED_CURSOR            Child cursor is marked for purging
ROLL_INVALID_MISMATCH    Marked for rolling invalidation and invalidation window exceeded

