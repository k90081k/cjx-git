﻿* 화면명 : Tablespace

* 용도 : 테이블스페이스의 현재 사용량 및 사용 추이 분석

* 주요 딕셔너리
  DBA_TABLESPACES
  DBA_DATA_FILES
  DBA_TABLESPACE_USAGE_METRICS
  DBA_HIST_TBSPC_SPACE_USAGE

* 특징
  - 테이블스페이스의 로우를 더블클릭하면, 특정 테이블스페이스의 사용추이를 볼 수 있다


* 참고 : FREE SPACE로 사용율 보기
WITH QTT_ALLC
AS
(
SELECT A.TABLESPACE_NAME
      ,SUM(A.BYTES)            TBS_SIZE_B
      ,SUM(A.MAXBYTES)         TBS_MAX_SIZE_B
  FROM (
        SELECT TABLESPACE_NAME
              ,BYTES
              ,MAXBYTES
          FROM DBA_DATA_FILES
        UNION ALL
        SELECT TABLESPACE_NAME
              ,BYTES
              ,MAXBYTES
          FROM DBA_TEMP_FILES
       ) A
 GROUP BY A.TABLESPACE_NAME
),
QTT_FREE
AS
(
SELECT A.TABLESPACE_NAME
      ,SUM(A.BYTES)            TBS_FREE_SIZE_B
  FROM (
        SELECT TABLESPACE_NAME
              ,BYTES
          FROM DBA_FREE_SPACE
        UNION ALL
        SELECT TABLESPACE_NAME
              ,FREE_SPACE
          FROM DBA_TEMP_FREE_SPACE
       ) A
 GROUP BY A.TABLESPACE_NAME
)
SELECT A.*
      ,A.TBS_SIZE_B - NVL(B.TBS_FREE_SIZE_B, 0)
                              USE_SIZE_B
      ,ROUND(((A.TBS_SIZE_B - NVL(B.TBS_FREE_SIZE_B, 0))/A.TBS_SIZE_B)*100, 2)
                              USE_RATE
  FROM QTT_ALLC A
      ,QTT_FREE B
 WHERE B.TABLESPACE_NAME(+) = A.TABLESPACE_NAME
 ORDER BY A.TABLESPACE_NAME
;