﻿* 화면명 : DB Feature Usage

* 용도 : DB의 기능 중 사용한 적이 있는 기능을 체크

* 주요 딕셔너리
  DBA_FEATURE_USAGE_STATISTICS

* 특징
