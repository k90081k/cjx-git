﻿
* 화면명 : Column Search

* 용도 : 컬럼명, 속성명 검색을 통한 도메인 타입 일치 분석

* 주요 딕셔너리
  DBA_TABLES
  DBA_TAB_COMMENTS
  DBA_TAB_COLUMNS
  DBA_COL_COMMENTS

* 특징
  - 컬럼(Column)명 또는 속성(Attribute)명으로 조회하여, 도메인의 데이터타입 등이 일치하는지 확인할 수 있다.

* 참고
  - 날짜 타입에 대한 권고
    오라클에는 일자만을 담을 수 있는 순수한 DATE 데이터타입이 존재하지 않는다
    오라클의 DATE 타입은 다른 DBMS에서 사용하는 DATETIME 타입에 가깝다
    따라서, 오라클에서 진정한 DATE 데이터타입을 제공하기까지는 선택이 필요하다
    현실적으로 오라클에서 일자만을 담아야 하는 데이터타입을 사용할 때는 DATE 또는 VARCHAR2(8)을 혼용되고 있다
    DATE 데이터타입을 사용하게 되면, 날짜타입이 아닌 데이터가 들어갈 우려는 없지만 잘못된 시분초 데이터가 들어갈 가능성이 존재한다
    VARCHAR2(8) 데이터타입을 사용하게 되면, 날짜타입이 아닌 데이터가 들어갈 우려가 있다
    두 가지 타입 모두 부족함이 있으므로, 상대적으로 오류 확률이 적은 DATE 타입을 사용하는 것이 타당하다
    오류를 방지하지 위해서는 테이블에 체크제약(Check Constrait)을 설정해야 만족스러울 것이다. 

    <예>
    -- DATE 타입인데, YYYYMMDD만 필요한 경우
    ALTER TABLE EMP ADD CONSTRAINT CK_INVALID_DATE CHECK (HIREDATE = TRUNC(HIREDATE));
    
    -- VARCHAR2(8)인 경우 DATE 타입에 맞는지 체크
    ALTER TABLE EMP ADD CONSTRAINT CK_INVALID_DATE CHECK (RETIRE_DATE = TO_CHAR(TO_DATE(RETIRE_DATE, 'YYYYMMDD'), 'YYYYMMDD'));


 - ISDATE 함수
CREATE OR REPLACE FUNCTION ISDATE(PV_STR      VARCHAR2)
RETURN NUMBER
/*
STRING이 DATE 포맷에 맞는지 체크하는 함수
*/
IS
V_DATETIME       DATE;
BEGIN
    IF PV_STR IS NULL THEN
        RETURN NULL;
    END IF;
    
    IF LENGTH(PV_STR) = 14 THEN
        V_DATETIME := TO_DATE(PV_STR, 'YYYYMMDDHH24MISS');
    ELSE
        V_DATETIME := TO_DATE(PV_STR, 'YYYYMMDD');
    END IF;

    RETURN 1;
    
EXCEPTION
    WHEN OTHERS THEN
        RETURN 0;
END;
/
