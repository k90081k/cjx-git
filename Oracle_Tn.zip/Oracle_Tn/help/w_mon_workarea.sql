﻿
* 화면명 : SQL Workarea

* 용도 : SQL Workarea의 사용 현황 분석

* 주요 딕셔너리
  GV$SQL_WORKAREA_ACTIVE
  GV$SQL_WORKAREA
  GV$SQL
  GV$SESSION

* 특징
  - [SQL Workarea Active] 라디오버튼이 체크된 상태에서는 SQL_WORKAREA_ACTIVE를 사용하여,
    현재 Workarea를 사용하고 있는 세션/SQL 정보를 보여준다
  - [SQL Workarea Active OnePass/MultiPass] 라디오버튼이 체크된 상태에서는 SQL_WORKAREA를 사용하여,
    Workarea 사용 이력을 보여준다. 주로, OnePass나 MultiPass가 발생한 적이 있는 SQL을 추출하는 목적이다.

* 참고
  - SQL Workarea
    쿼리에서 Group by, Order by(Window Sort 포함), Hash Join 등의 오퍼레이션이 발생하면, 메모리(PGA)를 사용하여 이 동작이 수행된다
    이때, 처리해야 할 데이터량이 많아 할당 받은 메모리내에서 오퍼레이션을 수행할 수 없으면 디스크(Temp Segment)를 사용한다
    처리해야 할 절대량이 많아 디스크 사용이 불가피할 수 있지만, 이렇게 되면 SQL의 수행 성능이 급격히 저하된다.
    따라서, Workarea 사용을 꾸준히 관찰하여 오퍼레이션이 되도록 메모리안에서 처리되도록 하는 것이 튜닝 포인트다.

  - Execution 구분
    1) Optimal Executions : Workarea 사용시 메모리(PGA) 내에서 처리가 이루어진 경우
    2) OnePass Executions : Workarea 사용시 Temp 영역(Disk)을 1번 사용하여 처리가 이루어진 경우
    3) MultiPass Executions : Workarea 사용시 Temp 영역(Disk)을 2번 이상 사용하여 처리가 이루어진 경우

  - Workarea 조정
    1) 현재 설정 조회 : WORKAREA_SIZE_POLICY가 AUTO면 기본 설정을 따르고, MANUAL이면 조정한 WORKAREA 사용

       SELECT A.NAME                 PARAMETER_NAME
             ,A.VALUE                SESSION_VALUE
             ,A.ISSES_MODIFIABLE     ISSES_MODIFIABLE
             ,A.DESCRIPTION          DESCRIPTION
         FROM V$PARAMETER A
         WHERE UPPER(NAME) LIKE 'WORKAREA_SIZE_POLICY'
            OR UPPER(NAME) LIKE 'SORT%AREA%SIZE'
            OR UPPER(NAME) LIKE 'HASH%AREA%SIZE'
         ORDER BY A.NAME DESC
       ;

    2) WorkArea 조정 : Alter Session으로 Sort Area를 500Mb로 조정, 범위는 2Gb(2,147,483,647) 이하로 조정 가능
       500Mb = 512*(1024*1024)

       ALTER SESSION SET WORKAREA_SIZE_POLICY    = MANUAL;
       ALTER SESSION SET SORT_AREA_SIZE          = 536870912;
       ALTER SESSION SET SORT_AREA_RETAINED_SIZE = 536870912;

ALTER SESSION SET WORKAREA_SIZE_POLICY    = MANUAL;
ALTER SESSION SET SORT_AREA_SIZE          = 2147483647;
ALTER SESSION SET SORT_AREA_RETAINED_SIZE = 2147483647;
ALTER SESSION SET DB_FILE_MULTIBLOCK_READ_COUNT = 128;

    3) WorkArea 조정 : Alter Session으로 WORKAREA_SIZE_POLICY를 AUTO로 변경
       ALTER SESSION SET WORKAREA_SIZE_POLICY    = AUTO;
   
       ===> 주의사항
          * 프로그램에서 수행되는 SQL에서는 WorkArea를 조정하지 않는다
            => PGA의 범위를 넘어서 메모리를 할당할 수 있기 때문에, 실수하면 서버 메모리 부족으로 DB가 DOWN될 수 있다
          * 반드시 필요한 경우에만 사용한다
            => 짧은 시간안에 인덱스를 생성하거나 조인하여 대량의 데이터를 처리해야 하는 경우 등 제한적인 용도로만 사용한다