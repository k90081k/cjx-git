﻿
* 화면명 : Resource Usage

* 용도 : CPU, SGA, PGA 등 시스템 리소스 분석

* 주요 딕셔너리
  DBA_HIST_SYSMETRIC_SUMMARY
  DBA_HIST_SGA
  DBA_HIST_PGASTAT

* 특징
 
* 참고
