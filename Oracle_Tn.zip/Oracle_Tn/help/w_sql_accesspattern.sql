﻿
* 화면명 : Table Access Pattern

* 용도 : 특정 테이블에 대한 엑세스 패턴 분석

* 주요 딕셔너리
  DBA_TABLES
  DBA_INDEXES
  GV$SQL_PLAN
  DBA_HIST_SQL_PLAN
  DBA_PART_INDEXES
  DBA_CONSTRAINTS
  DBA_IND_COLUMNS
  DBA_SEGMENTS

* 특징
  - [Index List]에서는 해당 테이블의 인덱스 목록을 보여주며, 각각의 인덱스에 대해 별도의 id를 부여한다
  - [Access Pattern]에서는 테이블에 대한 엑세스 패턴을 보여준다.
  - 각각의 인덱스 번호는 위에서 부여한 인덱스 id에 매핑된다.
  - [Access Pattern]에서 [Plan] 버튼을 누르면, 실행계획을 보여준다.

* 참고
