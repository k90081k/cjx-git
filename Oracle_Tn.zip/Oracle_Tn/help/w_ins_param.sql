﻿* 화면명 : Database Parameter

* 용도 : Instance별 Database Parameter 확인

* 주요 딕셔너리
  GV$PARAMETER
  GV$RESOURCE_LIMIT

* 특징
  - Instance별로 Database Parameter 확인하여, 인스턴스간의 차이, 변경여부 등을 확인할 수 있다
  - RESOURCE_LIMIT과 비교하여 파라미터의 변경 가능성을 체크해 볼 수 있다

* 참고
  - 실행계획에 영향을 주는 파라미터의 조정
  --------------------------------------------------------------------------------------------------------
   _optim_peek_user_binds             : 10G 이상, 디폴트 TRUE, 권장 FALSE
   _optimizer_use_feedback            : 11G 이상, 디폴트 TRUE, 권장 FALSE
   _optimizer_adaptive_cursor_sharing : 11G 이상, 디폴트 TRUE, 권장 FALSE
   optimizer_adaptive_plans           : 12G 이상, 디폴트 TRUE, 권장 FALSE
  --------------------------------------------------------------------------------------------------------


* 참고 S*T 히든 파마미터 조정
  --------------------------------------------------------------------------------------------------------
_optimizer_nlj_hj_adaptive_join, false
_optimizer_aggr_groupby_elim, false
_optimizer_gather_feedback, false
_optimizer_strans_adaptive_pruning, false
_optimizer_adaptive_plans, false
_optimizer_dsdir_usage_control, 0
_optimizer_batch_table_access_by_rowid, false
_px_adaptive_dist_method, off
_optimizer_gather_stats_on_load, false
_optimizer_ansi_rearchitecture, false
_optimizer_use_feedback, false
_optimizer_adaptive_cursor_sharing, false
_optimizer_extended_cursor_sharing, none
_optimizer_extented_cursor_sharing_rel, none
_optimizer_connect_by_cost_based, false
  --------------------------------------------------------------------------------------------------------