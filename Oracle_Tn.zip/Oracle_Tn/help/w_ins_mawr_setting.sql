﻿* Manual AWR
  - AWR을 사용할 수 없는 오라클 Standard Edition에서 성능 관련 지표를 수집하는 기능
  - 수집주기는 시간 단위, 보관주기는 일 단위로 설정 가능
  - 성능지표는 최소한으로 수집함

<관련 오브젝트 목록>
------------------------------------------------------------------------------------
* 권한 : 딕셔너리를 읽고 저장하는 권한, 스케줄링 권한 필요
  - CONNECT, RESOURCE, SELECT ANY DICTIONARY, CREATE VIEW, CREATE JOB

* 테이블
  - <기본테이블>
  - MAWR_CONTROL  : MAWR 설정
  - MAWR_SNAPSHOT : SNAPSHOT
  - MAWR_SYSSTAT  : V$SYS_TIME_MODEL, V$SYSSTAT, V$SYSTEM_EVENT, V$SYS_METRIC, V$SGA, V$PGASTAT
  - MAWR_SEGSTAT  : V$SEGSTAT
  - MAWR_SQLSTAT  : V$SQLSTAT

  - <적재테이블>
  - MAWR_SYSSTAT_LOAD : SYSSTAT 직전, 현재 데이터 적재
  - MAWR_SEGSTAT_LOAD : SEGSTAT 직전, 현재 데이터 적재
  - MAWR_SEGSTAT_TEMP : SEGSTAT을 현재 그대로 적재
  - MAWR_SQLSTAT_LOAD : SQLSTAT 직전, 현재 데이터 적재
  - MAWR_SQLSTAT_TEMP : SQLSTAT을 현재 그대로 적재

* 뷰
  - AWR_SNAP  : SNAPSHOT
  - AWR_STAT  : TIME, SYSSTAT, METRIC, SGA, PGA
  - AWR_EVENT : TOP EVENT
  - AWR_TABLE : TOP SEGMENT(테이블 단위로 집계)
  - AWR_SQL   : TOP SQL

* 패키지(PKG_MAWR)
  - PKG_MAWR.CREATE_SNAPSHOT : 스냅샷 생성
  - PKG_MAWR.DROP_SNAPSHOT   : 스냅샷 제거
  - PKG_MAWR.MAWR_ENABLE     : MAWR 활성화 : 스케줄링 등록
  - PKG_MAWR.MAWR_DISABLE    : MAWR 비활성화 : 스케줄링 제거
  - PKG_MAWR.MAWR_SETTING    : MAWR 설정변경
------------------------------------------------------------------------------------

<사용방법>
------------------------------------------------------------------------------------
1) [Manual AWR Script 보기] 버튼을 클릭하여, 계정을 생성하고(필요시), 권한을 부여

2) 권한을 부여받은 계정에서 테이블, 뷰, 패키지를 생성

3) Manual AWR을 활성화함(스케줄링)
BEGIN
    PKG_MAWR.MAWR_ENABLE;
END;
/

4) 필요시 Manual AWR을 비활성화함(스케줄링 제거)
BEGIN
    PKG_MAWR.MAWR_DISABLE;
END;
/

5) 필요시 Manual AWR의 수집옵션 변경
BEGIN
    PKG_MAWR.MAWR_SETTING(SNAP_INTERVAL =>  1  --> 수집주기(단위:시간)
                         ,SNAP_STORE    => 40  --> 보관주기(단위:일자)
                         ,SNAP_LEVEL    =>  3  --> 수집수준(1 : 최소수준, 2 : +SEGMENT, 3 : +SQL)
                         ,SNAP_TOPN     => 30  --> SQL TOPN(단위:갯수)
                         );
END;
/

6) 수집된 내용 조회
-- SUMMARY 데이터
SELECT *
  FROM AWR_STAT A
;

-- 시스템 데이터 : V$SYS_TIME_MODEL, V$SYSSTAT, V$SYSTEM_EVENT, V$SYS_METRIC, V$SGA, V$PGA_STAT
SELECT *
  FROM MAWR_SYSSTAT A
;

-- TOP EVENT
SELECT A.*
  FROM AWR_EVENT A
;

-- TOP SEGMENT(테이블 단위로 집계)
SELECT A.*
  FROM AWR_TABLE A
;

-- TOP SQL
SELECT A.*
  FROM AWR_SQL A
;

------------------------------------------------------------------------------------
