﻿
* 화면명 : SQL Analysis

* 용도 : 개별 SQL에 대한 상세한 분석 정보 제공

* 주요 딕셔너리
  DBA_HIST_SQLSTAT
  GV$SQL
  DBA_HIST_SQLTEXT
  GV$SQL_PLAN
  DBA_HIST_SQL_PLAN
  GV$SQL_BIND_CAPTURE
  DBA_HIST_SQLBIND
  GV$ACTIVE_SESSION_HISTORY
  DBA_HIST_ACTIVE_SESS_HISTORY
  DBA_OBJECTS
  DBA_DATA_FILES

* 특징
  - SQL Text 탭 : SQL 문장 전체를 보여준다 (SQL Text를 클립보드로 복사 가능)
  - SQL PLAN 탭 : SQL의 실제 실행계획을 보여준다
  - Active Session History 탭 : 조회기간 내 SQL의 ASH 정보를 보여준다
  - Bind Variable : 샘플링된 바인드 변수 값을 보여 준다 (바인스변수값을 클립보드로 복사 가능)

* 참고

 (1) SQL 수행 테스트
   - GATHER_PLAN_STATISTICS 힌트를 이용하여, SQL 수행
   - SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_CURSOR(NULL, NULL, 'ADVANCED ALLSTATS LAST -ROWS')) 로 결과 도출
  예)
-------------------------------------------------------------------------------------------------------
SELECT /*+ GATHER_PLAN_STATISTICS */
       A.* 
FROM DUAL A
;
-------------------------------------------------------------------------------------------------------
SELECT * 
FROM TABLE(DBMS_XPLAN.DISPLAY_CURSOR(NULL, NULL, 'ALLSTATS LAST -ROWS'))
;
-------------------------------------------------------------------------------------------------------

(2) SQL PURGE
-- SQL 찾기
SELECT ADDRESS, HASH_VALUE
      ,CHILD_NUMBER
      ,INST_ID
      ,A.PLAN_HASH_VALUE
      ,A.LAST_ACTIVE_TIME
      ,A.*
  FROM GV$SQL A
 WHERE A.SQL_ID = 'cmm6639c24007'
 ORDER BY A.CHILD_NUMBER
         ,A.INST_ID
         ,A.PLAN_HASH_VALUE
;

-- Shared Pool의 SQL Cache 삭제
BEGIN
    -- V$SQLAREA의              ADDRESS,  HASH_VALUE
    SYS.DBMS_SHARED_POOL.PURGE('B5092DCC, 1602179686', 'C');
END;
/
