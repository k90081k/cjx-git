﻿
* 화면명 : Lock

* 용도 : 락/락 오브젝트 조회

* 주요 딕셔너리
  GV$LOCK
  GV$LOCKED_OBJECT
  DBA_OBJECTS
  GV$SESSION

* 특징
  - [Lock]이 체크되어 있으면, GV$LOCK을 이용하여 세션 중심의 락 정보를 보여준다(TX, TM Lock만 조회)
  - [Lock Object]가 체크되어 있으면, GV$LOCKED_OBJECT를 이용하여 락이 걸린 오브젝트 중심의 락 정보를 보여준다

* 참고


