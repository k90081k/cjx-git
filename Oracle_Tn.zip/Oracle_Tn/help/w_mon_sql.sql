﻿


-- 세션의 모듈명 지정 : 모듈명과 action명을 임의로 지정
BEGIN
    DBMS_APPLICATION_INFO.SET_MODULE(module_name => 'SQL Tuning', action_name => '#1'); 
END;
/