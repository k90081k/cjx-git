/*
-------------------------------------------------------
-- 10.���� ���� : SYSTEM �������� ����
-------------------------------------------------------
CREATE USER MAWR IDENTIFIED BY "2" DEFAULT TABLESPACE TS_MAWR;

-- ��ųʸ� ��ȸ ���� �� �� ���� ����, �����ٸ��� ���� ����
GRANT CONNECT, RESOURCE, SELECT ANY DICTIONARY, CREATE VIEW, CREATE JOB TO MAWR;
*/

-------------------------------------------------------
-- 20.���̺� ���� : MAWR ����ڷ� ����
-------------------------------------------------------
-- CONTROL : DBA_HIST_WR_CONTROL
--DROP TABLE MAWR_CONTROL PURGE;

CREATE TABLE MAWR_CONTROL
(SNAP_INTERVAL      NUMBER(3)      --> �����ֱ�(�ð�), ������ġ�ֱ�
,SNAP_STORE         NUMBER(3)      --> �����ֱ�(��)
,SNAP_LEVEL         NUMBER(1)      --> �������� : => 1 : �ּҼ���, 2 : +SEGMENT, 3 : +SQL
,SNAP_TOPN          NUMBER(3)      --> SQL TOP N
)
;

COMMENT ON COLUMN MAWR_CONTROL.SNAP_INTERVAL IS '�����ֱ� => ����:�ð�';
COMMENT ON COLUMN MAWR_CONTROL.SNAP_STORE    IS '�����ֱ� => ����:��';
COMMENT ON COLUMN MAWR_CONTROL.SNAP_LEVEL    IS '�������� => 1 : �ּҼ���, 2 : +SEGMENT, 3 : +SQL';
COMMENT ON COLUMN MAWR_CONTROL.SNAP_TOPN     IS 'SQL TOP N => SQL�� TOPN';

CREATE UNIQUE INDEX MAWR_CONTROL_PK ON MAWR_CONTROL (SNAP_INTERVAL);
ALTER TABLE MAWR_CONTROL ADD CONSTRAINT MAWR_CONTROL_PK PRIMARY KEY (SNAP_INTERVAL) USING INDEX MAWR_CONTROL_PK;

-- AWR_CONTROL �ʱⰪ ����
INSERT INTO MAWR_CONTROL(SNAP_INTERVAL, SNAP_STORE, SNAP_LEVEL, SNAP_TOPN) VALUES(1, 10, 3, 30);
COMMIT;

-- ������
--DROP SEQUENCE SEQ_SNAP_ID;

CREATE SEQUENCE SEQ_SNAP_ID
INCREMENT BY 1 START WITH 1
MAXVALUE 9999999999999999999999999999
MINVALUE 1 
NOCYCLE
CACHE 10
ORDER
;

-- SNAPSHOT : DBA_HIST_SNAPSHOT
--DROP TABLE MAWR_SNAPSHOT PURGE;

CREATE TABLE MAWR_SNAPSHOT
(SNAP_ID            NUMBER         --> ������ID
,FR_TIME            DATE           --> ���۽ð�
,TO_TIME            DATE           --> ����ð�(�������)
,STARTUP_TIME       DATE           --> �ν��Ͻ� ���۽ð�
,SNAP_LEVEL         NUMBER(1)      --> 
,SNAP_TOPN          NUMBER(3)      --> 
)
;

COMMENT ON COLUMN MAWR_SNAPSHOT.SNAP_ID      IS '������ID';
COMMENT ON COLUMN MAWR_SNAPSHOT.FR_TIME      IS '���۽ð�';
COMMENT ON COLUMN MAWR_SNAPSHOT.TO_TIME      IS '����ð�(�������)';
COMMENT ON COLUMN MAWR_SNAPSHOT.STARTUP_TIME IS '�ν��Ͻ����۽ð�';
COMMENT ON COLUMN MAWR_SNAPSHOT.SNAP_LEVEL   IS '�������� => MAWR_CONTROL.SNAP_LEVEL';
COMMENT ON COLUMN MAWR_SNAPSHOT.SNAP_TOPN    IS 'SQL TOP N => MAWR_CONTROL.SNAP_TOPN';

CREATE UNIQUE INDEX MAWR_SNAPSHOT_PK ON MAWR_SNAPSHOT (SNAP_ID);
ALTER TABLE MAWR_SNAPSHOT ADD CONSTRAINT MAWR_SNAPSHOT_PK PRIMARY KEY (SNAP_ID) USING INDEX MAWR_SNAPSHOT_PK;

CREATE INDEX MAWR_SNAPSHOT_X1 ON MAWR_SNAPSHOT (FR_TIME, TO_TIME, SNAP_ID);

-- SYSSTAT : DBA_HIST_SYSSTAT, DBA_HIST_SYS_TIME_MODEL, DBA_HIST_SYSTEM_EVENT, DBA_HIST_SYSMETRIC_SUMMARY
--DROP TABLE MAWR_SYSSTAT PURGE;

CREATE TABLE MAWR_SYSSTAT
(SNAP_ID            NUMBER         --> ������ID
,FR_TIME            DATE           --> ���۽ð�
,TO_TIME            DATE           --> ����ð�(�������)
,STAT_TYPE          VARCHAR2(10)   --> STAT ���� : TIME, STAT, EVENT, METRIC
,STAT_ID            NUMBER         --> STAT ID
,STAT_NAME          VARCHAR2(64)   --> STAT NAME
,VALUE              NUMBER         --> DELTA VALUE
,TOTAL_VALUE        NUMBER         --> TOTAL VALUE
)
;

COMMENT ON COLUMN MAWR_SYSSTAT.SNAP_ID     IS '������ID';
COMMENT ON COLUMN MAWR_SYSSTAT.FR_TIME     IS '���۽ð�';
COMMENT ON COLUMN MAWR_SYSSTAT.TO_TIME     IS '����ð�';
COMMENT ON COLUMN MAWR_SYSSTAT.STAT_TYPE   IS 'STAT���� => TIME, STAT, EVENT, METRIC';
COMMENT ON COLUMN MAWR_SYSSTAT.STAT_ID     IS 'STAT ID => ';
COMMENT ON COLUMN MAWR_SYSSTAT.STAT_NAME   IS 'STAT NAME => ';
COMMENT ON COLUMN MAWR_SYSSTAT.VALUE       IS 'DELTA VALUE => ';
COMMENT ON COLUMN MAWR_SYSSTAT.TOTAL_VALUE IS 'TOTAL VALUE => ';

CREATE UNIQUE INDEX MAWR_SYSSTAT_PK ON MAWR_SYSSTAT (SNAP_ID, STAT_TYPE, STAT_ID);
ALTER TABLE MAWR_SYSSTAT ADD CONSTRAINT MAWR_SYSSTAT_PK PRIMARY KEY (SNAP_ID, STAT_TYPE, STAT_ID) USING INDEX MAWR_SYSSTAT_PK;

CREATE INDEX MAWR_SYSSTAT_X1 ON MAWR_SYSSTAT (FR_TIME, TO_TIME, SNAP_ID, STAT_TYPE, STAT_ID);

-- SYSSTAT TEMPORARY : V$ ������ �״�� �����Ͽ�, ����� ���� �����͸� ǥ��
--DROP TABLE MAWR_SYSSTAT_LOAD PURGE;

CREATE TABLE MAWR_SYSSTAT_LOAD
(SNAP_ID            NUMBER         --> ������ID
,LOAD_TIME          DATE           --> ����ð�
,STAT_TYPE          VARCHAR2(10)   --> STAT ���� : TIME, STAT, EVENT, METRIC
,STAT_ID            NUMBER         --> STAT ID
,STAT_NAME          VARCHAR2(64)   --> STAT NAME
,TOTAL_VALUE        NUMBER         --> TOTAL VALUE
)
;

CREATE UNIQUE INDEX MAWR_SYSSTAT_LOAD_PK ON MAWR_SYSSTAT_LOAD (SNAP_ID, STAT_TYPE, STAT_ID);
ALTER TABLE MAWR_SYSSTAT_LOAD ADD CONSTRAINT MAWR_SYSSTAT_LOAD_PK PRIMARY KEY (SNAP_ID, STAT_TYPE, STAT_ID) USING INDEX MAWR_SYSSTAT_LOAD_PK;

CREATE INDEX MAWR_SYSSTAT_LOAD_X1 ON MAWR_SYSSTAT_LOAD (FR_TIME, TO_TIME, SNAP_ID, STAT_TYPE, STAT_ID);

-- SEGSTAT : SEGSTAT
--DROP TABLE MAWR_SEGSTAT PURGE;

CREATE TABLE MAWR_SEGSTAT
(SNAP_ID            NUMBER         --> ������ID
,FR_TIME            DATE           --> ���۽ð�
,TO_TIME            DATE           --> ����ð�(�������)
,TABLE_OWNER        VARCHAR2(30)   --> 
,TABLE_NAME         VARCHAR2(30)   --> 
,LOGICAL_READS      NUMBER         --> 
,PHYSICAL_READS     NUMBER         --> 
,DB_BLOCK_CHANGES   NUMBER         --> 
,ROW_LOCK_WAITS     NUMBER         --> 
)
;

CREATE UNIQUE INDEX MAWR_SEGSTAT_PK ON MAWR_SEGSTAT (SNAP_ID, TABLE_OWNER, TABLE_NAME);
ALTER TABLE MAWR_SEGSTAT ADD CONSTRAINT MAWR_SEGSTAT_PK PRIMARY KEY (SNAP_ID, TABLE_OWNER, TABLE_NAME) USING INDEX MAWR_SEGSTAT_PK;


-- SEGSTAT LOAD : V$ ������ �״�� �����Ͽ�, ����� ���� �����͸� ǥ��
--DROP TABLE MAWR_SEGSTAT_LOAD PURGE;

CREATE TABLE MAWR_SEGSTAT_LOAD
(SNAP_ID            NUMBER         --> ������ID
,LOAD_TIME          DATE           --> ����ð�
,TABLE_OWNER        VARCHAR2(30)   --> 
,TABLE_NAME         VARCHAR2(30)   --> 
,LOGICAL_READS      NUMBER         --> 
,PHYSICAL_READS     NUMBER         --> 
,DB_BLOCK_CHANGES   NUMBER         --> 
,ROW_LOCK_WAITS     NUMBER         --> 
)
;

CREATE UNIQUE INDEX MAWR_SEGSTAT_LOAD_PK ON MAWR_SEGSTAT_LOAD (SNAP_ID, TABLE_OWNER, TABLE_NAME);
ALTER TABLE MAWR_SEGSTAT_LOAD ADD CONSTRAINT MAWR_SEGSTAT_LOAD_PK PRIMARY KEY (SNAP_ID, TABLE_OWNER, TABLE_NAME) USING INDEX MAWR_SEGSTAT_LOAD_PK;


-- SEGSTAT TEMPORARY : V$ ������ �״�� ����
--DROP TABLE MAWR_SEGSTAT_TEMP PURGE;

CREATE TABLE MAWR_SEGSTAT_TEMP
(OBJECT_ID          NUMBER         --> 
,STAT_NAME          VARCHAR2(64)   --> STAT NAME
,VALUE              NUMBER         --> 
)
;

-- SQLSTAT
--DROP TABLE MAWR_SQLSTAT PURGE;

CREATE TABLE MAWR_SQLSTAT
PCTFREE 0
NOLOGGING
AS
SELECT CAST(NULL AS NUMBER)        SNAP_ID
      ,CAST(NULL AS DATE)          FR_TIME
      ,CAST(NULL AS DATE)          TO_TIME
      ,A.SQL_ID                    SQL_ID
      ,A.EXECUTIONS                EXECUTIONS
      ,A.ROWS_PROCESSED            ROWS_PROCESSED
      ,A.ELAPSED_TIME              ELAPSED_TIME
      ,A.CPU_TIME                  CPU_TIME
      ,A.BUFFER_GETS               BUFFER_GETS
      ,A.DISK_READS                DISK_READS
      ,A.DIRECT_WRITES             DIRECT_WRITES
      ,A.USER_IO_WAIT_TIME         IOWAIT_TIME
      ,A.APPLICATION_WAIT_TIME     APWAIT_TIME
      ,A.CONCURRENCY_WAIT_TIME     CCWAIT_TIME
      ,A.CLUSTER_WAIT_TIME         CLWAIT_TIME
      ,A.PLAN_HASH_VALUE           PLAN_HASH_VALUE
      ,A.SQL_TEXT                  SQL_TEXT
      ,C.NAME                      COMMAND_TYPE
      ,TO_DATE(B.FIRST_LOAD_TIME, 'YYYY-MM-DD/HH24:MI:SS')
                                   FIRST_LOAD_TIME
      ,B.LAST_ACTIVE_TIME          LAST_ACTIVE_TIME
      ,B.PARSING_SCHEMA_NAME       PARSING_SCHEMA_NAME
      ,B.MODULE                    MODULE
      ,B.ACTION                    ACTION
  FROM V$SQLSTATS    A
      ,V$SQLAREA     B
      ,AUDIT_ACTIONS C
 WHERE B.SQL_ID(+) = A.SQL_ID
   AND C.ACTION(+) = B.COMMAND_TYPE
   AND 1 = 2
;

CREATE UNIQUE INDEX MAWR_SQLSTAT_PK ON MAWR_SQLSTAT (SNAP_ID, SQL_ID);
ALTER TABLE MAWR_SQLSTAT ADD CONSTRAINT MAWR_SQLSTAT_PK PRIMARY KEY (SNAP_ID, SQL_ID) USING INDEX MAWR_SQLSTAT_PK;

-- SQLSTAT LOAD : V$ ������ �״�� �����Ͽ�, ����� ���� �����͸� ǥ��
--DROP TABLE MAWR_SQLSTAT_LOAD PURGE;

CREATE TABLE MAWR_SQLSTAT_LOAD
PCTFREE 0
NOLOGGING
AS
SELECT CAST(NULL AS NUMBER)        SNAP_ID
      ,CAST(NULL AS DATE)          LOAD_TIME
      ,A.SQL_ID                    SQL_ID
      ,A.EXECUTIONS                EXECUTIONS
      ,A.ROWS_PROCESSED            ROWS_PROCESSED
      ,A.ELAPSED_TIME              ELAPSED_TIME
      ,A.CPU_TIME                  CPU_TIME
      ,A.BUFFER_GETS               BUFFER_GETS
      ,A.DISK_READS                DISK_READS
      ,A.DIRECT_WRITES             DIRECT_WRITES
      ,A.USER_IO_WAIT_TIME         IOWAIT_TIME
      ,A.APPLICATION_WAIT_TIME     APWAIT_TIME
      ,A.CONCURRENCY_WAIT_TIME     CCWAIT_TIME
      ,A.CLUSTER_WAIT_TIME         CLWAIT_TIME
      ,A.PLAN_HASH_VALUE           PLAN_HASH_VALUE
      ,A.SQL_TEXT                  SQL_TEXT
      ,C.NAME                      COMMAND_TYPE
      ,TO_DATE(B.FIRST_LOAD_TIME, 'YYYY-MM-DD/HH24:MI:SS')
                                   FIRST_LOAD_TIME
      ,B.LAST_ACTIVE_TIME          LAST_ACTIVE_TIME
      ,B.PARSING_SCHEMA_NAME       PARSING_SCHEMA_NAME
      ,B.MODULE                    MODULE
      ,B.ACTION                    ACTION
  FROM V$SQLSTATS    A
      ,V$SQLAREA     B
      ,AUDIT_ACTIONS C
 WHERE B.SQL_ID(+) = A.SQL_ID
   AND C.ACTION(+) = B.COMMAND_TYPE
   AND 1 = 2
;

CREATE UNIQUE INDEX MAWR_SQLSTAT_LOAD_PK ON MAWR_SQLSTAT_LOAD (SNAP_ID, SQL_ID);
ALTER TABLE MAWR_SQLSTAT_LOAD ADD CONSTRAINT MAWR_SQLSTAT_LOAD_PK PRIMARY KEY (SNAP_ID, SQL_ID) USING INDEX MAWR_SQLSTAT_LOAD_PK;

-- SQLSTAT TEMPORARY : V$ ������ �״�� ����
--DROP TABLE MAWR_SQLSTAT_TEMP PURGE;

CREATE TABLE MAWR_SQLSTAT_TEMP
PCTFREE 0
NOLOGGING
AS
SELECT A.SQL_ID                    SQL_ID
      ,A.EXECUTIONS                EXECUTIONS
      ,A.ROWS_PROCESSED            ROWS_PROCESSED
      ,A.ELAPSED_TIME              ELAPSED_TIME
      ,A.CPU_TIME                  CPU_TIME
      ,A.BUFFER_GETS               BUFFER_GETS
      ,A.DISK_READS                DISK_READS
      ,A.DIRECT_WRITES             DIRECT_WRITES
      ,A.USER_IO_WAIT_TIME         IOWAIT_TIME
      ,A.APPLICATION_WAIT_TIME     APWAIT_TIME
      ,A.CONCURRENCY_WAIT_TIME     CCWAIT_TIME
      ,A.CLUSTER_WAIT_TIME         CLWAIT_TIME
      ,A.PLAN_HASH_VALUE           PLAN_HASH_VALUE
      ,A.SQL_TEXT                  SQL_TEXT
      ,C.NAME                      COMMAND_TYPE
      ,TO_DATE(B.FIRST_LOAD_TIME, 'YYYY-MM-DD/HH24:MI:SS')
                                   FIRST_LOAD_TIME
      ,B.LAST_ACTIVE_TIME          LAST_ACTIVE_TIME
      ,B.PARSING_SCHEMA_NAME       PARSING_SCHEMA_NAME
      ,B.MODULE                    MODULE
      ,B.ACTION                    ACTION
  FROM V$SQLSTATS    A
      ,V$SQLAREA     B
      ,AUDIT_ACTIONS C
 WHERE B.SQL_ID(+) = A.SQL_ID
   AND C.ACTION(+) = B.COMMAND_TYPE
   AND 1 = 2
;


-------------------------------------------------------
-- 30.���ú� ���� : MAWR ����ڷ� ����
-------------------------------------------------------
-- SNAPSHOT
CREATE OR REPLACE VIEW AWR_SNAP
AS
SELECT A.SNAP_ID
      ,A.FR_TIME
      ,A.TO_TIME
      ,TO_CHAR(A.FR_TIME, 'YYYYMMDD')
                              SNAP_DATE
      ,TO_CHAR(A.FR_TIME, 'HH24')
                              SNAP_HOUR
      ,TO_CHAR(A.FR_TIME, 'DY')
                              SNAP_DAY
      ,ROUND((A.TO_TIME - A.FR_TIME)*24*60*60)
                              ELAP_TIME
      ,A.STARTUP_TIME
      ,A.SNAP_LEVEL
      ,A.SNAP_TOPN
      ,CASE WHEN A.STARTUP_TIME BETWEEN A.FR_TIME AND A.TO_TIME
         THEN 0
         ELSE 1
       END                    VALID_YN
  FROM MAWR_SNAPSHOT A
;

-- �⺻ STAT
CREATE OR REPLACE VIEW AWR_STAT
AS
SELECT A.*
      ,ROUND(A.DB_TIME/A.ELAP_TIME, 2)
                              DB_TIME_PS
      ,ROUND(A.CPU_TIME/A.ELAP_TIME, 2)
                              CPU_TIME_PS
      ,ROUND(A.EXECUTE_COUNT/A.ELAP_TIME)
                              EXECUTE_COUNT_PS
      ,ROUND(A.LOGICAL_READS/A.ELAP_TIME)
                              LOGICAL_READS_PS
      ,ROUND(A.TRANSACTIONS/A.ELAP_TIME, 2)
                              TRANSACTIONS_PS
  FROM (
        SELECT A.SNAP_ID
              ,A.FR_TIME
              ,A.TO_TIME
              ,A.SNAP_DATE
              ,A.SNAP_HOUR
              ,A.SNAP_DAY
              ,A.ELAP_TIME
              ,B.VALUE                DB_TIME
              ,C.VALUE                CPU_TIME
              ,CASE WHEN B.VALUE > C.VALUE
                 THEN B.VALUE - C.VALUE
                 ELSE 0
               END                    WAIT_TIME
              ,D.VALUE                EXECUTE_COUNT
              ,E.VALUE                LOGICAL_READS
              ,NVL(F.VALUE, 0) + NVL(G.VALUE, 0)
                                      TRANSACTIONS
              ,H.VALUE                CPU_USAGE
              ,I.MEMORY_USAGE         MEMORY_USAGE
          FROM AWR_SNAP      A
              ,MAWR_SYSSTAT  B
              ,MAWR_SYSSTAT  C
              ,MAWR_SYSSTAT  D
              ,MAWR_SYSSTAT  E
              ,MAWR_SYSSTAT  F
              ,MAWR_SYSSTAT  G
              ,MAWR_SYSSTAT  H
              ,(
                SELECT B.SNAP_ID
                      ,ROUND((
                       SUM(
                       CASE WHEN (B.STAT_TYPE = 'SGA')
                              OR (B.STAT_TYPE = 'PGA' AND B.STAT_NAME = 'total PGA allocated')
                         THEN B.VALUE
                       END)/MAX(A.VALUE))*100, 3)
                                    MEMORY_USAGE
                  FROM V$OSSTAT     A
                      ,MAWR_SYSSTAT B
                 WHERE A.STAT_NAME = 'PHYSICAL_MEMORY_BYTES'
                   AND B.STAT_TYPE IN ('SGA', 'PGA')
                 GROUP BY B.SNAP_ID
               ) I
         WHERE B.SNAP_ID  (+) = A.SNAP_ID
           AND B.STAT_TYPE(+) = 'TIME'
           AND B.STAT_NAME(+) = 'DB time'
           AND C.SNAP_ID  (+) = A.SNAP_ID
           AND C.STAT_TYPE(+) = 'TIME'
           AND C.STAT_NAME(+) = 'DB CPU'
           AND D.SNAP_ID  (+) = A.SNAP_ID
           AND D.STAT_TYPE(+) = 'STAT'
           AND D.STAT_NAME(+) = 'execute count'
           AND E.SNAP_ID  (+) = A.SNAP_ID
           AND E.STAT_TYPE(+) = 'STAT'
           AND E.STAT_NAME(+) = 'session logical reads'
           AND F.SNAP_ID  (+) = A.SNAP_ID
           AND F.STAT_TYPE(+) = 'STAT'
           AND F.STAT_NAME(+) = 'user commits'
           AND G.SNAP_ID  (+) = A.SNAP_ID
           AND G.STAT_TYPE(+) = 'STAT'
           AND G.STAT_NAME(+) = 'user rollbacks'
           AND H.SNAP_ID  (+) = A.SNAP_ID
           AND H.STAT_TYPE(+) = 'METRIC'
           AND H.STAT_NAME(+) = 'Host CPU Utilization (%)'
           AND I.SNAP_ID  (+) = A.SNAP_ID
       ) A
 ORDER BY A.SNAP_ID
;

-- EVENT
CREATE OR REPLACE VIEW AWR_EVENT
AS
SELECT A.SNAP_ID
      ,A.FR_TIME
      ,A.TO_TIME
      ,A.STAT_ID              EVENT_ID
      ,A.STAT_NAME            EVENT_NAME
      ,A.VALUE                WAIT_TIME
      ,B.VALUE                DB_TIME
      ,CASE WHEN B.VALUE > 0
         THEN ROUND(A.VALUE/B.VALUE, 3)
       END                    DB_TIME_RATE
  FROM MAWR_SYSSTAT A
      ,MAWR_SYSSTAT B
 WHERE A.STAT_TYPE = 'EVENT'
   AND B.SNAP_ID   = A.SNAP_ID
   AND B.STAT_TYPE = 'TIME'
   AND B.STAT_NAME = 'DB time'
;

-- TABLE
CREATE OR REPLACE VIEW AWR_TABLE
AS
SELECT A.SNAP_ID
      ,A.FR_TIME
      ,A.TO_TIME
      ,A.TABLE_OWNER
      ,A.TABLE_NAME
      ,A.LOGICAL_READS
      ,A.PHYSICAL_READS
      ,B.VALUE                TOTAL_LOGICAL_READS
      ,ROUND((A.LOGICAL_READS/B.VALUE)*100, 2)
                              LOGICAL_READS_RATE
  FROM MAWR_SEGSTAT A
      ,MAWR_SYSSTAT B
 WHERE B.SNAP_ID   = A.SNAP_ID
   AND B.STAT_TYPE = 'STAT'
   AND B.STAT_NAME = 'session logical reads'
;

-- SQL
CREATE OR REPLACE VIEW AWR_SQL
AS
SELECT A.*
      ,CASE WHEN A.EXECUTIONS > 0
         THEN ROUND(A.ELAPSED_TIME/A.EXECUTIONS, 3)
       END                    AVG_ELAPSED_TIME
      ,CASE WHEN A.EXECUTIONS > 0
         THEN ROUND(A.BUFFER_GETS/A.EXECUTIONS)
       END                    AVG_BUFFER_GETS
      ,ROUND((A.ELAPSED_TIME/B.VALUE)*100, 2)
                              ELAPSED_TIME_RATE
      ,ROUND((A.BUFFER_GETS/C.VALUE)*100, 2)
                              BUFFER_GETS_RATE
  FROM MAWR_SQLSTAT A
      ,MAWR_SYSSTAT B
      ,MAWR_SYSSTAT C
 WHERE B.SNAP_ID   = A.SNAP_ID
   AND B.STAT_TYPE = 'TIME'
   AND B.STAT_NAME = 'DB time'
   AND C.SNAP_ID   = A.SNAP_ID
   AND C.STAT_TYPE = 'STAT'
   AND C.STAT_NAME = 'session logical reads'
;


-------------------------------------------------------
-- 40.��Ű�� ���� : MAWR ����ڷ� ����
-------------------------------------------------------
-- PACKAGE
CREATE OR REPLACE PACKAGE PKG_MAWR
IS

-- ������ ����
PROCEDURE CREATE_SNAPSHOT;

-- ������ ����
PROCEDURE DROP_SNAPSHOT  ;

-- MAWR Ȱ��ȭ : �����ٸ� ���
PROCEDURE MAWR_ENABLE;

-- MAWR ��Ȱ��ȭ : �����ٸ� ����
PROCEDURE MAWR_DISABLE;

-- ������ ��������
PROCEDURE MAWR_SETTING (SNAP_INTERVAL   NUMBER DEFAULT NULL  --> �����ֱ�(����:�ð�)
                       ,SNAP_STORE      NUMBER DEFAULT NULL  --> �����ֱ�(����:����)
                       ,SNAP_LEVEL      NUMBER DEFAULT NULL  --> ��������(1 : �ּҼ���, 2 : +SEGMENT, 3 : +SQL)
                       ,SNAP_TOPN       NUMBER DEFAULT NULL  --> SQL TOPN(����:����)
                       );

END;
/

-- PACKAGE BODY
CREATE OR REPLACE PACKAGE BODY PKG_MAWR
IS
--******************************************************************************
-- ������ ����
PROCEDURE CREATE_SNAPSHOT
IS
---------------------------------------
V_SNAP_INTERVAL     NUMBER;
V_SNAP_STORE        NUMBER;
V_SNAP_LEVEL        NUMBER;
V_SNAP_TOPN         NUMBER;
---------------------------------------
V_STARTUP_TIME      DATE;
---------------------------------------
V_SNAP_ID           NUMBER;
V_SNAP_ID_PREV      NUMBER;
V_FR_TIME           DATE;
V_TO_TIME           DATE := SYSDATE;
V_TO_TIME_PREV      DATE;
---------------------------------------
BEGIN
    -- 00.üũ
    SELECT A.SNAP_INTERVAL, A.SNAP_STORE, A.SNAP_LEVEL, A.SNAP_TOPN, SEQ_SNAP_ID.NEXTVAL
      INTO V_SNAP_INTERVAL, V_SNAP_STORE, V_SNAP_LEVEL, V_SNAP_TOPN, V_SNAP_ID
      FROM MAWR_CONTROL A
    ;

    -- 10.SNAPSHOT
    SELECT CASE
             WHEN A.MAX_TO_TIME >= B.STARTUP_TIME
               THEN A.MAX_TO_TIME + 1/24/60/60
             ELSE B.STARTUP_TIME
           END
          ,B.STARTUP_TIME
      INTO V_FR_TIME
          ,V_STARTUP_TIME
      FROM (
            SELECT MAX(A.TO_TIME)   MAX_TO_TIME
              FROM MAWR_SNAPSHOT A
           ) A
          ,V$INSTANCE B
    ;
    
    INSERT INTO MAWR_SNAPSHOT(  SNAP_ID, FR_TIME  ,   TO_TIME,   STARTUP_TIME,   SNAP_LEVEL,   SNAP_TOPN)
                      VALUES (V_SNAP_ID, V_FR_TIME, V_TO_TIME, V_STARTUP_TIME, V_SNAP_LEVEL, V_SNAP_TOPN);
    
    -- 20.LOAD - SYSSTAT
    INSERT INTO MAWR_SYSSTAT_LOAD
    SELECT V_SNAP_ID          SNAP_ID
          ,V_TO_TIME          LOAD_TIME
          ,A.*
      FROM (
            SELECT 'TIME'                 STAT_TYPE
                  ,A.STAT_ID              STAT_ID
                  ,A.STAT_NAME            STAT_NAME
                  ,A.VALUE                VALUE
              FROM V$SYS_TIME_MODEL A
             WHERE A.VALUE > 0
               AND A.STAT_NAME IN
                  ('DB time'
                  ,'DB CPU'
                  ,'sql execute elapsed time'
                  ,'hard parse elapsed time'
                  ,'background elapsed time'
                  )
            UNION ALL
            SELECT 'STAT'                 STAT_TYPE
                  ,A.STAT_ID              STAT_ID
                  ,A.NAME                 STAT_NAME
                  ,A.VALUE                VALUE
              FROM V$SYSSTAT A
             WHERE A.VALUE > 0
               AND A.NAME IN
                  ('db block changes'
                  ,'execute count'
                  ,'logons cumulative'
                  ,'parse count (hard)'
                  ,'parse count (total)'
                  ,'physical reads'
                  ,'physical writes'
                  ,'recursive calls'
                  ,'redo size'
                  ,'session logical reads'
                  ,'sorts (disk)'
                  ,'sorts (memory)'
                  ,'user calls'
                  ,'user commits'
                  ,'user rollbacks'
                  ,'workarea executions - multipass'
                  ,'workarea executions - onepass'
                  ,'workarea executions - optimal'
                  )
            UNION ALL
            SELECT 'EVENT'                STAT_TYPE
                  ,A.EVENT_ID             STAT_ID
                  ,A.EVENT                STAT_NAME
                  ,A.TIME_WAITED_MICRO    VALUE
              FROM V$SYSTEM_EVENT A
             WHERE A.WAIT_CLASS <> 'Idle'
               AND A.TOTAL_WAITS > 0
            UNION ALL
            SELECT 'METRIC'               STAT_TYPE
                  ,A.METRIC_ID            STAT_ID
                  ,A.METRIC_NAME          STAT_NAME
                  ,ROUND(A.VALUE, 3)      VALUE
              FROM V$SYSMETRIC A
             WHERE A.GROUP_ID = 2
               AND A.VALUE    > 0
               AND A.METRIC_NAME IN
                  ('Host CPU Utilization (%)'
                  ,'Buffer Cache Hit Ratio'
                  ,'Memory Sorts Ratio'
                  ,'Database Wait Time Ratio'
                  ,'Database CPU Time Ratio'
                  ,'Library Cache Hit Ratio'
                  ,'Cursor Cache Hit Ratio'
                  ,'PGA Cache Hit %'
                  ,'Database Time Per Sec'
                  ,'DB Block Changes Per Sec'
                  ,'Executions Per Sec'
                  ,'Hard Parse Count Per Sec'
                  ,'Logical Reads Per Sec'
                  ,'Logons Per Sec'
                  ,'Physical Reads Per Sec'
                  ,'Recursive Calls Per Sec'
                  ,'Redo Generated Per Sec'
                  ,'User Calls Per Sec'
                  ,'User Commits Per Sec'
                  ,'User Rollbacks Per Sec'
                  ,'User Transaction Per Sec'
                  )
            UNION ALL                  
            SELECT CASE WHEN A.NAME LIKE '%PGA%'
                     THEN 'PGA'
                     ELSE 'SGA'
                   END                    STAT_TYPE
                  ,CASE A.NAME
                     WHEN TRIM('Database Buffers   ') THEN 11
                     WHEN TRIM('Variable Size      ') THEN 12
                     WHEN TRIM('Fixed Size         ') THEN 13
                     WHEN TRIM('Redo Buffers       ') THEN 14
                     WHEN TRIM('total PGA allocated') THEN 21
                     WHEN TRIM('total PGA inuse    ') THEN 22
                   END                    STAT_ID
                  ,A.NAME                 STAT_NAME
                  ,A.VALUE                VALUE
              FROM (
                    SELECT NAME, VALUE
                      FROM V$SGA A
                    UNION ALL
                    SELECT NAME, VALUE
                      FROM V$PGASTAT A
                     WHERE A.NAME IN ('total PGA inuse', 'total PGA allocated')
                   ) A
           ) A
    ;
    
    IF V_SNAP_LEVEL >= 2 THEN
        -- 21.LOAD - SEGSTAT
        DELETE FROM MAWR_SEGSTAT_TEMP;
        
        INSERT INTO MAWR_SEGSTAT_TEMP
        SELECT A.OBJ#                 OBJECT_ID
              ,A.STATISTIC_NAME       STAT_NAME
              ,A.VALUE                VALUE
          FROM V$SEGSTAT A
         WHERE A.STATISTIC_NAME IN ('logical reads', 'physical reads')
           AND A.VALUE > 0
        ;
    END IF;
    
    IF V_SNAP_LEVEL >= 3 THEN
        -- 22.LOAD - SQLSTAT
        DELETE FROM MAWR_SQLSTAT_TEMP;
        
        INSERT INTO MAWR_SQLSTAT_TEMP
        SELECT A.SQL_ID                    SQL_ID
              ,A.EXECUTIONS                EXECUTIONS
              ,A.ROWS_PROCESSED            ROWS_PROCESSED
              ,A.ELAPSED_TIME              ELAPSED_TIME
              ,A.CPU_TIME                  CPU_TIME
              ,A.BUFFER_GETS               BUFFER_GETS
              ,A.DISK_READS                DISK_READS
              ,A.DIRECT_WRITES             DIRECT_WRITES
              ,A.USER_IO_WAIT_TIME         IOWAIT_TIME
              ,A.APPLICATION_WAIT_TIME     APWAIT_TIME
              ,A.CONCURRENCY_WAIT_TIME     CCWAIT_TIME
              ,A.CLUSTER_WAIT_TIME         CLWAIT_TIME
              ,A.PLAN_HASH_VALUE           PLAN_HASH_VALUE
              ,A.SQL_TEXT                  SQL_TEXT
              ,C.NAME                      COMMAND_TYPE
              ,TO_DATE(B.FIRST_LOAD_TIME, 'YYYY-MM-DD/HH24:MI:SS')
                                           FIRST_LOAD_TIME
              ,B.LAST_ACTIVE_TIME          LAST_ACTIVE_TIME
              ,B.PARSING_SCHEMA_NAME       PARSING_SCHEMA_NAME
              ,B.MODULE                    MODULE
              ,B.ACTION                    ACTION
          FROM V$SQLSTATS    A
              ,V$SQLAREA     B
              ,AUDIT_ACTIONS C
         WHERE B.SQL_ID(+) = A.SQL_ID
           AND C.ACTION(+) = B.COMMAND_TYPE
        ;
    END IF;
    
    -- ���� SNAP_ID
    SELECT MAX(S.SNAP_ID)
      INTO V_SNAP_ID_PREV
      FROM MAWR_SNAPSHOT S 
     WHERE S.SNAP_ID < V_SNAP_ID
    ;
    
    -- 30.MAWR ���� - SYSSTAT
    INSERT INTO MAWR_SYSSTAT
    WITH QTT_FR_SNAP
    AS
    (
    SELECT A.*
      FROM MAWR_SYSSTAT_LOAD A
     WHERE A.SNAP_ID = V_SNAP_ID_PREV
    ),
    QTT_TO_SNAP
    AS
    (
    SELECT A.*
      FROM MAWR_SYSSTAT_LOAD A
     WHERE A.SNAP_ID = V_SNAP_ID
    )
    SELECT V_SNAP_ID          SNAP_ID
          ,V_FR_TIME          FR_TIME
          ,V_TO_TIME          TO_TIME
          ,A.STAT_TYPE
          ,A.STAT_ID
          ,A.STAT_NAME
          ,CASE WHEN A.STAT_TYPE IN ('TIME', 'EVENT')
             THEN ROUND(A.VALUE/1000000)
             ELSE A.VALUE
           END                    VALUE
          ,CASE WHEN A.STAT_TYPE IN ('TIME', 'EVENT')
             THEN ROUND(A.TOTAL_VALUE/1000000)
             ELSE A.TOTAL_VALUE
           END                    TOTAL_VALUE
      FROM (
            SELECT A.STAT_TYPE
                  ,A.STAT_ID
                  ,A.STAT_NAME
                  ,A.TOTAL_VALUE
                  ,CASE WHEN A.STAT_TYPE IN ('METRIC', 'SGA', 'PGA')
                     THEN A.TOTAL_VALUE
                     ELSE A.TOTAL_VALUE - NVL(B.TOTAL_VALUE,0)
                   END                    VALUE
              FROM QTT_TO_SNAP A
                  ,QTT_FR_SNAP B
             WHERE B.STAT_TYPE(+) = A.STAT_TYPE
               AND B.STAT_ID  (+) = A.STAT_ID
           ) A
     WHERE CASE WHEN A.STAT_TYPE IN ('TIME', 'EVENT')
             THEN ROUND(A.VALUE/1000000)
             ELSE A.VALUE
           END > 0
    ;

    IF V_SNAP_LEVEL >= 2 THEN
        -- 31.MAWR ���� - SEGSTAT
        INSERT INTO MAWR_SEGSTAT_LOAD
        SELECT V_SNAP_ID                  SNAP_ID
              ,V_TO_TIME                  LOAD_TIME
              ,A.TABLE_OWNER              TABLE_OWNER
              ,A.TABLE_NAME               TABLE_NAME
              ,SUM(A.LOGICAL_READS   )    LOGICAL_READS
              ,SUM(A.PHYSICAL_READS  )    PHYSICAL_READS
              ,SUM(A.DB_BLOCK_CHANGES)    DB_BLOCK_CHANGES
              ,SUM(A.ROW_LOCK_WAITS  )    ROW_LOCK_WAITS
          FROM (
                SELECT CASE 
                         WHEN B.OBJECT_TYPE LIKE 'INDEX%'
                           THEN C.TABLE_OWNER
                         WHEN B.OBJECT_TYPE LIKE 'LOB'
                           THEN D.OWNER
                         ELSE B.OWNER
                       END                     TABLE_OWNER
                      ,CASE 
                         WHEN B.OBJECT_TYPE LIKE 'INDEX%'
                           THEN C.TABLE_NAME
                         WHEN B.OBJECT_TYPE LIKE 'LOB'
                           THEN D.TABLE_NAME
                         ELSE B.OBJECT_NAME
                       END                     TABLE_NAME
                      ,A.*
                  FROM (
                        SELECT /*+ NO_MERGE */
                               A.OBJECT_ID            OBJECT_ID
                              ,SUM(DECODE(A.STAT_NAME, 'logical reads', A.VALUE))
                                                      LOGICAL_READS
                              ,SUM(DECODE(A.STAT_NAME, 'physical reads', A.VALUE))
                                                      PHYSICAL_READS
                              ,SUM(DECODE(A.STAT_NAME, 'db block changes', A.VALUE))
                                                      DB_BLOCK_CHANGES
                              ,SUM(DECODE(A.STAT_NAME, 'row lock waits', A.VALUE))
                                                      ROW_LOCK_WAITS
                          FROM MAWR_SEGSTAT_TEMP A
                         GROUP BY A.OBJECT_ID
                       ) A
                      ,DBA_OBJECTS B
                      ,DBA_INDEXES C
                      ,DBA_LOBS    D
                 WHERE B.OBJECT_ID       = A.OBJECT_ID
                   AND C.OWNER       (+) = B.OWNER
                   AND C.INDEX_NAME  (+) = B.OBJECT_NAME
                   AND D.OWNER       (+) = B.OWNER
                   AND D.SEGMENT_NAME(+) = B.OBJECT_NAME
               ) A
         GROUP BY A.TABLE_OWNER
                 ,A.TABLE_NAME
        ;
        
        INSERT INTO MAWR_SEGSTAT
        WITH QTT_FR_SNAP
        AS
        (
        SELECT A.*
          FROM MAWR_SEGSTAT_LOAD A
         WHERE A.SNAP_ID = V_SNAP_ID_PREV
        ),
        QTT_TO_SNAP
        AS
        (
        SELECT A.*
          FROM MAWR_SEGSTAT_LOAD A
         WHERE A.SNAP_ID = V_SNAP_ID
        )
        SELECT V_SNAP_ID          SNAP_ID
              ,V_FR_TIME          FR_TIME
              ,V_TO_TIME          TO_TIME
              ,A.TABLE_OWNER
              ,A.TABLE_NAME
              ,A.LOGICAL_READS
              ,A.PHYSICAL_READS
              ,A.DB_BLOCK_CHANGES
              ,A.ROW_LOCK_WAITS
          FROM (
                SELECT A.TABLE_OWNER
                      ,A.TABLE_NAME
                      ,A.LOGICAL_READS    - NVL(B.LOGICAL_READS   ,0)   LOGICAL_READS
                      ,A.PHYSICAL_READS   - NVL(B.PHYSICAL_READS  ,0)   PHYSICAL_READS
                      ,A.DB_BLOCK_CHANGES - NVL(B.DB_BLOCK_CHANGES,0)   DB_BLOCK_CHANGES
                      ,A.ROW_LOCK_WAITS   - NVL(B.ROW_LOCK_WAITS  ,0)   ROW_LOCK_WAITS
                  FROM QTT_TO_SNAP A
                      ,QTT_FR_SNAP B
                 WHERE B.TABLE_OWNER(+) = A.TABLE_OWNER
                   AND B.TABLE_NAME (+) = A.TABLE_NAME
               ) A
         WHERE A.LOGICAL_READS > 0
        ;
    END IF;
    
    IF V_SNAP_LEVEL >= 3 THEN
        -- 32.MAWR ���� - SQLSTAT
        INSERT INTO MAWR_SQLSTAT_LOAD
        SELECT V_SNAP_ID                  SNAP_ID
              ,V_TO_TIME                  LOAD_TIME
              ,S.*
          FROM MAWR_SQLSTAT_TEMP S
        ;
        
        INSERT INTO MAWR_SQLSTAT
        SELECT V_SNAP_ID                   SNAP_ID
              ,V_FR_TIME                   FR_TIME
              ,V_TO_TIME                   TO_TIME
              ,A.SQL_ID                    SQL_ID
              ,A.EXECUTIONS                EXECUTIONS
              ,A.ROWS_PROCESSED            ROWS_PROCESSED
              ,A.ELAPSED_TIME/1000000      ELAPSED_TIME
              ,A.CPU_TIME    /1000000      CPU_TIME
              ,A.BUFFER_GETS               BUFFER_GETS
              ,A.DISK_READS                DISK_READS
              ,A.DIRECT_WRITES             DIRECT_WRITES
              ,A.IOWAIT_TIME /1000000      IOWAIT_TIME
              ,A.APWAIT_TIME /1000000      APWAIT_TIME
              ,A.CCWAIT_TIME /1000000      CCWAIT_TIME
              ,A.CLWAIT_TIME /1000000      CLWAIT_TIME
              ,A.PLAN_HASH_VALUE           PLAN_HASH_VALUE
              ,A.SQL_TEXT                  SQL_TEXT
              ,A.COMMAND_TYPE              COMMAND_TYPE
              ,A.FIRST_LOAD_TIME           FIRST_LOAD_TIME
              ,A.LAST_ACTIVE_TIME          LAST_ACTIVE_TIME
              ,A.PARSING_SCHEMA_NAME       PARSING_SCHEMA_NAME
              ,A.MODULE                    MODULE
              ,A.ACTION                    ACTION
          FROM (
                SELECT A.SQL_ID                    SQL_ID
                      ,A.EXECUTIONS     - NVL(B.EXECUTIONS    , 0)     EXECUTIONS
                      ,A.ROWS_PROCESSED - NVL(B.ROWS_PROCESSED, 0)     ROWS_PROCESSED
                      ,A.ELAPSED_TIME   - NVL(B.ELAPSED_TIME  , 0)     ELAPSED_TIME
                      ,A.CPU_TIME       - NVL(B.CPU_TIME      , 0)     CPU_TIME
                      ,A.BUFFER_GETS    - NVL(B.BUFFER_GETS   , 0)     BUFFER_GETS
                      ,A.DISK_READS     - NVL(B.DISK_READS    , 0)     DISK_READS
                      ,A.DIRECT_WRITES  - NVL(B.DIRECT_WRITES , 0)     DIRECT_WRITES
                      ,A.IOWAIT_TIME    - NVL(B.IOWAIT_TIME   , 0)     IOWAIT_TIME
                      ,A.APWAIT_TIME    - NVL(B.APWAIT_TIME   , 0)     APWAIT_TIME
                      ,A.CCWAIT_TIME    - NVL(B.CCWAIT_TIME   , 0)     CCWAIT_TIME
                      ,A.CLWAIT_TIME    - NVL(B.CLWAIT_TIME   , 0)     CLWAIT_TIME
                      ,A.PLAN_HASH_VALUE           PLAN_HASH_VALUE
                      ,A.SQL_TEXT                  SQL_TEXT
                      ,A.COMMAND_TYPE              COMMAND_TYPE
                      ,A.FIRST_LOAD_TIME           FIRST_LOAD_TIME
                      ,A.LAST_ACTIVE_TIME          LAST_ACTIVE_TIME
                      ,A.PARSING_SCHEMA_NAME       PARSING_SCHEMA_NAME
                      ,A.MODULE                    MODULE
                      ,A.ACTION                    ACTION
                  FROM MAWR_SQLSTAT_LOAD A
                      ,MAWR_SQLSTAT_LOAD B
                 WHERE A.SNAP_ID    = V_SNAP_ID
                   AND B.SNAP_ID(+) = V_SNAP_ID_PREV
                   AND B.SQL_ID   (+) = A.SQL_ID
                 ORDER BY A.ELAPSED_TIME - NVL(B.ELAPSED_TIME, 0) DESC
                         ,A.SQL_ID
               ) A
         WHERE A.ELAPSED_TIME >  0
           AND ROWNUM         <= V_SNAP_TOPN
        ;
    END IF;
    
    COMMIT;
    
    -- ���� ������ ����
    DROP_SNAPSHOT;
END;

--******************************************************************************
-- ������ ����
PROCEDURE DROP_SNAPSHOT
IS
V_FR_TIME           DATE;
V_SNAP_ID           NUMBER;
BEGIN
    -- 10.LOAD ���̺� ���� : �ֱ� 2�Ǹ� �ʿ���
    DELETE FROM MAWR_SEGSTAT_TEMP;
    DELETE FROM MAWR_SQLSTAT_TEMP;
    
    SELECT MIN(A.SNAP_ID)
      INTO V_SNAP_ID
      FROM (
            SELECT A.SNAP_ID
              FROM MAWR_SNAPSHOT A
             ORDER BY A.SNAP_ID DESC
           ) A
     WHERE ROWNUM <= 2
    ;
    
    DELETE FROM MAWR_SYSSTAT_LOAD T WHERE T.SNAP_ID < V_SNAP_ID;
    DELETE FROM MAWR_SEGSTAT_LOAD T WHERE T.SNAP_ID < V_SNAP_ID;
    DELETE FROM MAWR_SQLSTAT_LOAD T WHERE T.SNAP_ID < V_SNAP_ID;
    
    -- 20.SNAPSHOT ���̺� ���� : ������ ���� ����
    SELECT TRUNC(SYSDATE) - A.SNAP_STORE
      INTO V_FR_TIME       
      FROM MAWR_CONTROL A
    ;
    
    SELECT MAX(A.SNAP_ID)
      INTO V_SNAP_ID
      FROM MAWR_SNAPSHOT A
     WHERE A.FR_TIME < V_FR_TIME;
    
    DELETE FROM MAWR_SYSSTAT  T WHERE T.SNAP_ID <= V_SNAP_ID;
    DELETE FROM MAWR_SEGSTAT  T WHERE T.SNAP_ID <= V_SNAP_ID;
    DELETE FROM MAWR_SQLSTAT  T WHERE T.SNAP_ID <= V_SNAP_ID;
    DELETE FROM MAWR_SNAPSHOT T WHERE T.SNAP_ID <= V_SNAP_ID;
    
    COMMIT;
END;

--******************************************************************************
-- MAWR Ȱ��ȭ : �����ٸ� ���
PROCEDURE MAWR_ENABLE
IS
V_SNAP_INTERVAL   NUMBER         ;
V_JOB_NAME        VARCHAR2(30)   := 'JOB_MAWR_CREATE_SNAPSHOT';
V_JOB_ACTION      VARCHAR2(4000) := 'BEGIN PKG_MAWR.CREATE_SNAPSHOT; END;';
V_INTERVAL_OLD    VARCHAR2(4000);
V_INTERVAL_NEW    VARCHAR2(4000);
V_ENABLED         VARCHAR2(5) ;
BEGIN
    -- ���� üũ
    SELECT NVL(MAX(SNAP_INTERVAL), 1)
      INTO V_SNAP_INTERVAL
      FROM MAWR_CONTROL
    ;
    
    V_INTERVAL_NEW := 'FREQ=HOURLY;INTERVAL=' || TO_CHAR(V_SNAP_INTERVAL) || ';BYMINUTE=0;BYSECOND=0';
    
    -- JOB CHECK
    SELECT MAX(UPPER(A.REPEAT_INTERVAL))
          ,MAX(UPPER(A.ENABLED        ))
      INTO V_INTERVAL_OLD
          ,V_ENABLED
      FROM DBA_SCHEDULER_JOBS A
     WHERE A.OWNER      = SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA')
       AND A.JOB_NAME   = V_JOB_NAME
       AND A.JOB_ACTION = V_JOB_ACTION
    ;
    
    IF V_ENABLED IS NULL THEN
    -- JOB ���
    BEGIN
        DBMS_SCHEDULER.CREATE_JOB(JOB_NAME        => V_JOB_NAME
                                 ,JOB_TYPE        => 'PLSQL_BLOCK'
                                 ,JOB_ACTION      => V_JOB_ACTION
                                 ,REPEAT_INTERVAL => V_INTERVAL_NEW
                                 ,START_DATE      => SYSDATE
                                 ,ENABLED         => TRUE
                                 ,AUTO_DROP       => FALSE
                                 ,COMMENTS        => 'Manually AWR Data Collection'
                                 );
    END;
    ELSE
    -- JOB ����
    BEGIN
        IF V_INTERVAL_OLD <> V_INTERVAL_NEW THEN
            DBMS_SCHEDULER.SET_ATTRIBUTE(NAME      => V_JOB_NAME
                                        ,ATTRIBUTE => 'REPEAT_INTERVAL'
                                        ,VALUE     => V_INTERVAL_NEW
                                        );
        END IF;
        
        IF V_ENABLED = 'FALSE' THEN
            DBMS_SCHEDULER.ENABLE(NAME => V_JOB_NAME);
        END IF;
    END;
    END IF;
END;

--******************************************************************************
-- MAWR ��Ȱ��ȭ : �����ٸ� ����
PROCEDURE MAWR_DISABLE
IS
V_JOB_NAME        VARCHAR2(30)   := 'JOB_MAWR_CREATE_SNAPSHOT';
V_JOB_ACTION      VARCHAR2(4000) := 'BEGIN PKG_MAWR.CREATE_SNAPSHOT; END;';
V_EXIST           NUMBER;
BEGIN
    -- JOB CHECK
    SELECT COUNT(*)
      INTO V_EXIST
      FROM DBA_SCHEDULER_JOBS A
     WHERE A.OWNER      = SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA')
       AND A.JOB_NAME   = V_JOB_NAME
       AND A.JOB_ACTION = V_JOB_ACTION
    ;
    
    IF V_EXIST = 1 THEN
        DBMS_SCHEDULER.DROP_JOB(JOB_NAME => V_JOB_NAME);
    END IF;
END;

--******************************************************************************
-- MAWR ������ ��������
PROCEDURE MAWR_SETTING (SNAP_INTERVAL   NUMBER DEFAULT NULL  --> �����ֱ�(����:�ð�)
                       ,SNAP_STORE      NUMBER DEFAULT NULL  --> �����ֱ�(����:����)
                       ,SNAP_LEVEL      NUMBER DEFAULT NULL  --> ��������(1 : �ּҼ���, 2 : +SEGMENT, 3 : +SQL)
                       ,SNAP_TOPN       NUMBER DEFAULT NULL  --> SQL TOPN(����:����)
                       )
IS
V_SNAP_INTERVAL     NUMBER;
V_SNAP_STORE        NUMBER;
V_SNAP_LEVEL        NUMBER;
V_SNAP_TOPN         NUMBER;
V_ROW_COUNT         NUMBER;
BEGIN
    V_SNAP_INTERVAL := SNAP_INTERVAL;
    V_SNAP_STORE    := SNAP_STORE   ;
    V_SNAP_LEVEL    := SNAP_LEVEL   ;
    V_SNAP_TOPN     := SNAP_TOPN    ;
    
    SELECT COUNT(*)
          ,NVL(V_SNAP_INTERVAL, MAX(A.SNAP_INTERVAL))
          ,NVL(V_SNAP_STORE   , MAX(A.SNAP_STORE   ))
          ,NVL(V_SNAP_LEVEL   , MAX(A.SNAP_LEVEL   ))
          ,NVL(V_SNAP_TOPN    , MAX(A.SNAP_TOPN    ))
      INTO V_ROW_COUNT
          ,V_SNAP_INTERVAL
          ,V_SNAP_STORE
          ,V_SNAP_LEVEL
          ,V_SNAP_TOPN
      FROM MAWR_CONTROL A
    ;
    
    IF V_ROW_COUNT = 0 THEN
        -- AWR_CONTROL �ʱⰪ ����
        INSERT INTO MAWR_CONTROL(      SNAP_INTERVAL,           SNAP_STORE,            SNAP_LEVEL,           SNAP_TOPN) 
                          VALUES(NVL(V_SNAP_INTERVAL, 1), NVL(V_SNAP_STORE, 10), NVL(V_SNAP_LEVEL, 3), NVL(V_SNAP_TOPN, 30));
        COMMIT;
        
        MAWR_ENABLE;
    ELSE
        UPDATE MAWR_CONTROL T
           SET T.SNAP_INTERVAL = V_SNAP_INTERVAL
              ,T.SNAP_STORE    = V_SNAP_STORE
              ,T.SNAP_LEVEL    = V_SNAP_LEVEL
              ,T.SNAP_TOPN     = V_SNAP_TOPN
         WHERE T.SNAP_INTERVAL = V_SNAP_INTERVAL
            OR T.SNAP_STORE    = V_SNAP_STORE
            OR T.SNAP_LEVEL    = V_SNAP_LEVEL
            OR T.SNAP_TOPN     = V_SNAP_TOPN
        ;
        
        V_ROW_COUNT := SQL%ROWCOUNT;
        
        COMMIT;
        
        IF V_ROW_COUNT > 0 THEN
            MAWR_ENABLE;
        END IF;
        
    END IF;
    
END;

--******************************************************************************
END;
/

-------------------------------------------------------
-- 50.��Ű�� ��� : MAWR ����ڷ� ����
-------------------------------------------------------
-- Manual AWR Ȱ��ȭ
BEGIN
    PKG_MAWR.MAWR_ENABLE;
END;
/

-- Manual AWR ��Ȱ��ȭ
BEGIN
    PKG_MAWR.MAWR_DISABLE;
END;
/

-------------------------------------------------------
-- 60.�ٸ� ����ڷ� MAWR ��ȸ : SYNONYM�� Ȱ����
-------------------------------------------------------
/*
-- SYNONYM FOR MAWR TABLES
CREATE SYNONYM MAWR_CONTROL  FOR MAWR.MAWR_CONTROL ;
CREATE SYNONYM MAWR_SEGSTAT  FOR MAWR.MAWR_SEGSTAT ;
CREATE SYNONYM MAWR_SNAPSHOT FOR MAWR.MAWR_SNAPSHOT;
CREATE SYNONYM MAWR_SQLSTAT  FOR MAWR.MAWR_SQLSTAT ;
CREATE SYNONYM MAWR_SYSSTAT  FOR MAWR.MAWR_SYSSTAT ;

-- SYNONYM FOR MAWR VIEWS
CREATE SYNONYM AWR_EVENT     FOR MAWR.AWR_EVENT    ;
CREATE SYNONYM AWR_METRIC    FOR MAWR.AWR_METRIC   ;
CREATE SYNONYM AWR_SGA       FOR MAWR.AWR_SGA      ;
CREATE SYNONYM AWR_SNAP      FOR MAWR.AWR_SNAP     ;
CREATE SYNONYM AWR_SQL       FOR MAWR.AWR_SQL      ;
CREATE SYNONYM AWR_STAT      FOR MAWR.AWR_STAT     ;
CREATE SYNONYM AWR_TABLE     FOR MAWR.AWR_TABLE    ;
CREATE SYNONYM AWR_TIME      FOR MAWR.AWR_TIME     ;
*/
