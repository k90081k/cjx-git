﻿
* 화면명 : ASH Analysis

* 용도 : Active Session History에 대한 상세 조회 분석

* 주요 딕셔너리
  DBA_HIST_ACTIVE_SESS_HISTORY
  GV$ACTIVE_SESSION_HISTORY
  DBA_USERS
  DBA_OBJECTS

* 특징
  - Active Session History를 다양한 관점에서 조회하고 분석할 수 있다

* 참고
