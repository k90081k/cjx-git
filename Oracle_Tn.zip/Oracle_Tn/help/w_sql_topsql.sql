﻿
* 화면명 : TOP SQL

* 용도 : 특정 부하를 기준으로 특정 기간의 TOP SQL을 추출한다

* 주요 딕셔너리
  DBA_HIST_SNAPSHOT
  DBA_HIST_SQLSTAT
  DBA_HIST_SQLTEXT

* 특징
  - 정렬 기준을 설정하고 조회 기간을 설정한 후 조회하면, 정렬 기준별로 TOP SQL을 추출한다
  - [상세수행기록보기] 체크박스를 클릭하면, 조회기간의 스냅샷별로 특정 SQL의 수행기록을 볼 수 있다
  - [SQL Text], [SQL Stat] 버튼으로 해당 화면으로 이동할 수 있다


* 참고