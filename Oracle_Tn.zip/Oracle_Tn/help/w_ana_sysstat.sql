﻿
* 화면명 : System Statistics

* 용도 : 시스템 통계 지표에 대한 비교 분석

* 주요 딕셔너리
  DBA_HIST_SYSSTAT

* 특징
  - 2 개의 지표를 한꺼번에 조회하여 추이를 비교할 수 있다
 
* 참고
