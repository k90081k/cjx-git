﻿
* 화면명 : Wait Event

* 용도 : 주요 대기 이벤트 분석

* 주요 딕셔너리
  DBA_HIST_SYSTEM_EVENT
  DBA_HIST_SYS_TIME_MODEL
  DBA_HIST_ACTIVE_SESS_HISTORY

* 특징
  - Top Wait Event  : 대기를 주도하는 이벤트를 시간 비중별로 보여준다
  - Wait Event 추이 : [Top Wait Event]의 개별 이벤트를 더블 클릭하면, 개별 이벤트의 시간대별 추이와 그래프를 보여준다
  - Event SQL       : [Wait Event 추이]에서 <Event SQL> 버튼을 클릭하면, 해당 이벤트를 유발시킨 SQL을 ASH에서 추출하여 보여준다
 
* 참고
