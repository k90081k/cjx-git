﻿
* 화면명 : Object Search

* 용도 : 특정 명칭이나 타입으로 오브젝트 검색

* 주요 딕셔너리
  - DBA_OBJECTS

* 특징

* 참고
