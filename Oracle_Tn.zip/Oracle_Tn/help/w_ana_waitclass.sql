﻿
* 화면명 : Wait Class

* 용도 : Wait Class별 이벤트 대기시간 분석

* 주요 딕셔너리
  DBA_HIST_SYSTEM_EVENT

* 특징
  - SYSTEM_EVENT를 Wait Class 별로 집계하여, 어떤 부류의 이벤트가 대기시간의 주요 비중을 차지하는지 분석 

* 참고
  - Wait Class 별 대기 이벤트 조회
  
    SELECT A.WAIT_CLASS   WAIT_CLASS
          ,A.NAME         EVENT_NAME
          ,A.PARAMETER1
          ,A.PARAMETER2
          ,A.PARAMETER3
      FROM V$EVENT_NAME A
     ORDER BY 1, 2
    ;