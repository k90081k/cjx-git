﻿
* 화면명 : System Metric

* 용도 : System Metric을 이용한 시스템 분석

* 주요 딕셔너리
  DBA_HIST_SYSMETRIC_SUMMARY
  DBA_HIST_SYSMETRIC_HISTORY

* 특징
  - 목록에서 [History] 버튼이 보이는 경우 클릭하면, 스냅샷구간 동안의 상세한 추이를 볼 수 있다
 
* 참고
  - Oracle Standard Edition에서는 AWR 데이터가 기본적으로 수집되지 않는다
    다만, System Metric 항목과 Segment Statistics 항목만 수집된다
    따라서, System Metric을 잘 활용하면 System Time Model과 System Statistics의 항목을 유추해 볼 수 있다
    여기 Total Value* 컬럼은 Average 값과 초(intsize)를 곱하여 유추해낸 구간의 발생량 합계를 의미한다
    
