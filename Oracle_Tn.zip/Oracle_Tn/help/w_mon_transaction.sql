﻿
* 화면명 : Transaction

* 용도 : 현재 진행 중인 트랜잭션 정보

* 주요 딕셔너리
  GV$TRANSACTION
  GV$SESSION
  GV$TRANSACTION_ENQUEUE
  DBA_OBJECTS

* 특징

* 참고

