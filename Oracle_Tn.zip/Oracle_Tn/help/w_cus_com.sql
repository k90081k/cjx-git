﻿
* 화면명 : Customizing

* 용도 : 사용자가 정의한 SQL을 화면에 보여준다

* 사용방법
  1) ROOT 폴더(프로그램 ROOT)의 하위 폴더인 customizing 폴더에 SQL 파일을 저장한다.
  2) SQL 파일의 확장자는 반드시 .sql 이어야 하며, 내부에는 즉시 수행 가능한 SQL을 보관한다
     (GetSysdate.sql 파일 참고)
  3) 메인 Customizing 메뉴의 서브메뉴로 사용자 SQL이 디스플레이 된다.
