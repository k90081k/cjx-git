﻿
* 화면명 : Index List

* 용도 : 전체 인덱스에 대한 개괄적인 분석

* 주요 딕셔너리
  DBA_INDEXES
  DBA_IND_COLUMNS
  DBA_IND_PARTITIONS
  DBA_IND_SUBPARTITIONS
  DBA_TABLES
  DBA_TAB_COMMENTS
  DBA_SEGMENTS

* 특징
  - 유니크여부, 파티션여부, NOLOGGING, DEGREE 등을 조회할 수 있다
  - [Unusable] 체크박스를 클릭하면, Unusable 상태인 인덱스나 인덱스파티션, 인덱스 서브파티션이 존재하는지 확인할 수 있다
  - [Duplicate] 체크박스를 클릭하면, 테이블 내에 중복인덱스가 있는지 확인할 수 있다
    (※ 현재는 유니크 인덱스 여부와 관계없이 모두 추출한다. 유니크 인덱스와 중복인 경우는 성능상의 필요에 따라 발생할 수 있다)
  - [Segment Size 보기]를 체크박스를 체크한 후 조회하면, 인덱스에 할당된 세그먼트 사이즈를 볼 수 있다.
  - [Index Reorg] 체크박스를 클릭하면, 인덱스 리오그(리빌드) 후보를 확인할 수 있다
    => 통계상의 블록수(DBA_INDEXES.LEAF_BLOCKS) 대비 세그먼트의 블록수(DBA_SEGMENTS.BLOCKS)가 200% 이상인 인덱스

* 참고

* 인덱스 네이밍룰 : 테이블명은 27자 이하로
  - PK 인덱스     : PK_[TABLE_NAME], UNIQUE, NOT NULL, PK CONSTRAINT
  - UNIQUE 인덱스 : U1_[TABLE_NAME], UNIQUE, UNIQUE CONSTRAINT 포함
  - 일반인덱스    : X1_[TABLE_NAME] X1~X9, XA~XZ - 36개까지 가능

  