﻿
* 화면명 : SQL Compare

* 용도 : 특정 SQL_ID의 수행 기록 비교 분석

* 주요 딕셔너리
  DBA_HIST_SQLSTAT

* 특징
 -SQL1과 SQL2를 입력한 후에 비교할 항목을 선택하면, 주어진 기간 동안 두 SQL의 특정 항목 추이를 비교할 수 있다

* 참고


SDFDS