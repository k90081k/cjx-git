﻿* 화면명 : Manual AWR Analysis

* 용도 : Manual AWR로 수집한 성능 지표에 대한 조회

* 주요 딕셔너리
  - AWR_SNAP     : SNAPSHOT
  - AWR_STAT     : TIME, SYSSTAT, METRIC, SGA, PGA 등 주요 지표의 SUMMARY
  - MAWR_SYSSTAT : WAIT EVENT
  - MAWR_SEGSTAT : TABLE의 I/O
  - MAWR_SQLSTAT : TOP SQL

* 특징
