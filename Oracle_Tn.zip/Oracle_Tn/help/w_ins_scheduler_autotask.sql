﻿
* 화면명 : Scheduler Auto Task

* 용도 : Auto Task로 처리되는 스케줄러 조회

* 주요 딕셔너리
DBA_AUTOTASK_CLIENT
DBA_AUTOTASK_TASK
DBA_SCHEDULER_WINDOW_GROUPS
DBA_SCHEDULER_WINGROUP_MEMBERS
DBA_SCHEDULER_WINDOWS
DBA_AUTOTASK_CLIENT_HISTORY

* 특징

* 참고

--------------------------------------------------------------------------------
-- 1.predefined automated maintenance tasks
--------------------------------------------------------------------------------
   Automatic Optimizer Statistics Collection
   Automatic Segment Advisor
   Automatic SQL Tuning Advisor

--------------------------------------------------------------------------------
-- 2.Enabling and Disabling Maintenance Tasks
--------------------------------------------------------------------------------
BEGIN
    DBMS_AUTO_TASK_ADMIN.DISABLE(CLIENT_NAME => 'sql tuning advisor'
                                ,OPERATION   => NULL
                                ,WINDOW_NAME => NULL);
END;
/

BEGIN
    DBMS_AUTO_TASK_ADMIN.ENABLE( CLIENT_NAME => 'sql tuning advisor'
                               , OPERATION   => NULL
                               , WINDOW_NAME => NULL);
END;
/

To enable or disable all automated maintenance tasks for all windows, call the ENABLE or DISABLE procedure with no arguments.
EXECUTE DBMS_AUTO_TASK_ADMIN.DISABLE;

--------------------------------------------------------------------------------
-- 3.Enabling and Disabling Maintenance Tasks for Specific Maintenance Windows
--------------------------------------------------------------------------------
BEGIN
    DBMS_AUTO_TASK_ADMIN.DISABLE(CLIENT_NAME => 'sql tuning advisor'
                                ,OPERATION   => NULL
                                ,WINDOW_NAME => 'MONDAY_WINDOW');
END;
/

--------------------------------------------------------------------------------
-- 4.Configuring Maintenance Windows
--------------------------------------------------------------------------------
BEGIN
    DBMS_SCHEDULER.DISABLE(NAME  => 'SATURDAY_WINDOW');
  
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME      => 'SATURDAY_WINDOW'
                                ,ATTRIBUTE => 'DURATION'
                                ,VALUE     => numtodsinterval(4, 'hour'));
                                
    DBMS_SCHEDULER.ENABLE(NAME => 'SATURDAY_WINDOW');
END;
/

--------------------------------------------------------------------------------
-- 5.Predefined Maintenance Windows
--------------------------------------------------------------------------------
MONDAY_WINDOW    Starts at 10 p.m. on Monday     and ends at 2 a.m.
TUESDAY_WINDOW   Starts at 10 p.m. on Tuesday    and ends at 2 a.m.
WEDNESDAY_WINDOW Starts at 10 p.m. on Wednesday  and ends at 2 a.m.
THURSDAY_WINDOW  Starts at 10 p.m. on Thursday   and ends at 2 a.m.
FRIDAY_WINDOW    Starts at 10 p.m. on Friday     and ends at 2 a.m.
SATURDAY_WINDOW  Starts at  6 a.m. on Saturday   and is 20 hours long.
SUNDAY_WINDOW    Starts at  6 a.m. on Sunday     and is 20 hours long.

--------------------------------------------------------------------------------
-- 6.Automated Maintenance Tasks Database Dictionary Views
--------------------------------------------------------------------------------
DBA_AUTOTASK_CLIENT_JOB        Contains information about currently running Scheduler jobs created for automated maintenance tasks. It provides information about some objects targeted by those jobs, as well as some additional statistics from previous instantiations of the same task. Some of this additional data is taken from generic Scheduler views.
DBA_AUTOTASK_CLIENT            Provides statistical data for each automated maintenance task over 7-day and 30-day periods.
DBA_AUTOTASK_JOB_HISTORY       Lists the history of automated maintenance task job runs. Jobs are added to this view after they finish executing.
DBA_AUTOTASK_WINDOW_CLIENTS    Lists the windows that belong to MAINTENANCE_WINDOW_GROUP, along with the Enabled or Disabled status for the window for each maintenance task. Primarily used by Enterprise Manager.
DBA_AUTOTASK_CLIENT_HISTORY    Provides per-window history of job execution counts for each automated maintenance task. This information is viewable in the Job History page of Enterprise Manager.

--------------------------------------------------------------------------------
-- *일괄적인 윈도우 시간 변경
--------------------------------------------------------------------------------
DECLARE
V_BYHOUR     VARCHAR2(10) := '2';
BEGIN
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'MONDAY_WINDOW'   , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=MON;BYHOUR=' || V_BYHOUR || ';BYMINUTE=0; BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'TUESDAY_WINDOW'  , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=TUE;BYHOUR=' || V_BYHOUR || ';BYMINUTE=0; BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'WEDNESDAY_WINDOW', ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=WED;BYHOUR=' || V_BYHOUR || ';BYMINUTE=0; BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'THURSDAY_WINDOW' , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=THU;BYHOUR=' || V_BYHOUR || ';BYMINUTE=0; BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'FRIDAY_WINDOW'   , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=FRI;BYHOUR=' || V_BYHOUR || ';BYMINUTE=0; BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'SATURDAY_WINDOW' , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=SAT;BYHOUR=' || V_BYHOUR || ';BYMINUTE=0; BYSECOND=0');
    DBMS_SCHEDULER.SET_ATTRIBUTE(NAME => 'SUNDAY_WINDOW'   , ATTRIBUTE => 'REPEAT_INTERVAL', VALUE => 'FREQ=DAILY;BYDAY=SUN;BYHOUR=' || V_BYHOUR || ';BYMINUTE=0; BYSECOND=0');
END;
/