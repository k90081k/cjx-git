﻿
* 화면명 : Database Instance

* 용도 : Database와 Instance의 기본정보 확인

* 주요 딕셔너리
   V$DATABASE
   V$PARAMETER
   V$NLS_PARAMETERS
   GV$INSTANCE
   GV$OSSTAT
   GV$SGA, GV$PGASTAT

* 특징
   - DB 전체의 Data Size를 보려면, [Show Data Size] 체크박스를 클릭한 후 조회한다.
   - Instance의 DB Memory(%)는 (SGA Size + PGA Size)/Phishycal Memory의 비중을 의미한다



<Database Performance Tuning Guide> 중에서 PGA에 대한 설명
-------------------------------------------------------------------------------------------
You must then divide the resulting memory between the SGA and the PGA.

For OLTP systems, the PGA memory typically accounts for a small fraction of the total memory available (for example, 20%), leaving 80% for the SGA.
For DSS systems running large, memory-intensive queries, PGA memory can typically use up to 70% of that total (up to 2.2 GB in this example).

Good initial values for the parameter PGA_AGGREGATE_TARGET might be:

For OLTP: PGA_AGGREGATE_TARGET = (total_mem * 80%) * 20%
For DSS: PGA_AGGREGATE_TARGET  = (total_mem * 80%) * 50%

where total_mem is the total amount of physical memory available on the system.
In this example, with a value of total_mem equal to 4 GB, you can initially set PGA_AGGREGATE_TARGET to 1600 MB for a DSS system and to 655 MB for an OLTP system.
-------------------------------------------------------------------------------------------

* 온라인   : DB메모리 => 물리메모리*80%, SGA => DB메모리*80%, PGA => DB메모리*20%
      100G : DB메모리 => 80Gb, SGA => 64Gb, PGA => 16Gb
 
* 비온라인 : DB메모리 => 물리메모리*80%, SGA => DB메모리*50%, PGA => DB메모리*50%
      100G : DB메모리 => 80Gb, SGA => 40Gb, PGA => 40Gb
-------------------------------------------------------------------------------------------

<정리>
-------------------------------------------------------------------------------------------
* 온라인   : DB메모리 => 물리메모리*70%, SGA => DB메모리*80~85%, PGA => DB메모리*15~20%
      100G : DB메모리 => 70Gb, SGA => 62Gb, PGA => 8Gb

  => 위와 같은 구성시 OS가 사용하는 10% 정도를 포함해서 OS 메모리 사용률은 80% 정도가 됨
  => PGA는 DB 특성에 따라 10 ~ 20% 범위내에서 비율을 조정할 수 있음
-------------------------------------------------------------------------------------------