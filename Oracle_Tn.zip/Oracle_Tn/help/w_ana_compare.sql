﻿
* 화면명 : Date Compare

* 용도 : 주요 DB지표를 정하고, 2개의 일자간의 하루동안 추이를 비교

* 주요 딕셔너리
  DBA_HIST_SYS_TIME_MODEL
  DBA_HIST_SYSSTAT
  DBA_HIST_SYSTEM_EVENT
  DBA_HIST_SYSMETRIC_SUMMARY

* 특징
  - 특정한 두 기간 동안의 DB 지표를 비교할 수 있다
  - System Metric의 경우 평균값을 사용할 것인지 최대값을 사용할 것인지 선택할 수 있다
 
* 참고
