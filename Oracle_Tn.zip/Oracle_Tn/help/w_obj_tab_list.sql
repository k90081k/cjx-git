﻿
* 화면명 : Table List

* 용도 : 전체 테이블에 대한 개괄적인 분석

* 주요 딕셔너리
  DBA_TABLES
  DBA_TAB_COMMENTS

* 특징
  - 파티션된 테이블, Nologging/DOP가 설정된 테이블을 조회할 수 있다

* 참고

